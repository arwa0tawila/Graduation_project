import 'dart:async';

import 'package:carousel_pro/carousel_pro.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geoflutterfire/geoflutterfire.dart';
import 'package:intl/intl.dart';
import '../drawerADV.dart';
import 'AllCompitionsAdv.dart';
import 'NotificationsAdv.dart';

class ChallangePageForAdv extends StatefulWidget {

  var date;

  final name;

  final price;
  final descrption;

  ChallangePageForAdv({this.date, this.descrption, this.name, this.price});

  State<StatefulWidget> createState() {
    return ChallangePageForAdvState();
  }
}

class ChallangePageForAdvState extends State<ChallangePageForAdv> {
  var price=30;
  DateTime pickedDate;
  TimeOfDay _time = new TimeOfDay.now();
  final couponsReference =
  FirebaseFirestore.instance.collection("ChallangesPart");
  final firestore = FirebaseFirestore.instance;
  FirebaseAuth auth = FirebaseAuth.instance;
  Geoflutterfire geo = Geoflutterfire();
  String _selectedDate = 'Tap to select date';
  TextEditingController _chaNameControllar = TextEditingController();
  TextEditingController _desCodeControllar = TextEditingController();
  var maxlen=7;
  final postUrl = "https://fcm.googleapis.com/fcm/send";

  Future<void> _openDatePicker(BuildContext context) async {
    final DateTime d = await showDatePicker(
        context: context,
        initialDate: DateTime.now(),
        firstDate: new DateTime(2021),
        lastDate: new DateTime(2021));
    if (d != null) {
      setState(() {
        _selectedDate = d.toLocal().toString();
      });
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime d = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2015),
      lastDate: DateTime(2020),
    );
    if (d != null)
      setState(() {
        _selectedDate = new DateFormat.yMMMMd("en_US").format(d);
      });

  }

  @override
  void initState() {
    super.initState();
    pickedDate = DateTime.now();
    getStoreLocation(auth.currentUser.uid);
    getStoreName(auth.currentUser.uid);
    _someFunction(auth.currentUser.uid);
  }

  _pickDate() async {
    DateTime date = await showDatePicker(
      context: context,
      firstDate: DateTime(DateTime.now().year),
      lastDate: DateTime(DateTime.now().year + 1),



      initialDate: pickedDate,
    );
    if (date != null)
      setState(() {
        pickedDate = date;
      });
  }

  _pickTime() async {
    TimeOfDay date = await showTimePicker(context: context, initialTime: _time);


    if (date != null)
      setState(() {
        _time = date;
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "add new Challange",

          style: TextStyle(color: Colors.pink[900]),
        ),
        backgroundColor: Colors.orange[200],
        centerTitle: true,
        actions: [
          IconButton(
              icon: Icon(
                Icons.notifications,
                color: Colors.pink[900],
              ),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (BuildContext context) {
                      return notificationAdv();
                    }));
              })
        ],
      ),
      drawer: drawerADV(),
      body: Container(
        color: Colors.orange[50],
        child:ListView(
          children: [
            //  SizedBox(height: 100,),

            //     SizedBox(height: 20,),
            Container(
              height: 130.0,
              width: double.infinity, // عشان يبقا الصورة بعرض الصفحة كلها
              child: Carousel(
                // boxFit: BoxFit.cover, // عشان يخلي كل الصور اللي بضيفها اد الشاشة
                autoplay: true,
                // ان الصور تتحرك بشكل تلقائي
                autoplayDuration: Duration(seconds: 2),
                // كل اد ايه تتحرك الصورة
                animationCurve: Curves.fastOutSlowIn,
                animationDuration: Duration(milliseconds: 1000),
                dotSize: 8.0,
                // خاصة بالدواير الصغيرة لما يحرك الصورة وكده والقيمة الافتراضية هيا 8
                dotSpacing: 10,
                // المسافة ما بين كل نقطة والتانية
                dotColor: Colors.black,
                // لون النقط
                dotIncreasedColor: Color(0xFFFF335C),
                dotBgColor: Colors.pink[900].withOpacity(0.5),
                dotPosition: DotPosition.bottomCenter,
                // هنا لها خلفية لونها اوارنج وفيها خاصية الشفافية
                dotVerticalPadding: 00.0,
                // المسافة بين الشريط واسفل الصورة ، خليته 0 لان مش عاوزة مسافة
                borderRadius: true,
                //بتخلي  الشريط اللى ورا النقط
                radius: Radius.circular(40),
                // بتزود الدوران اللى ف الشريط
                overlayShadow: true,
                // بتزود التظليل بتاع الشريط
                overlayShadowColors: Colors.brown,
                // لون الشادو اللي ورا الخط
                overlayShadowSize: 0.2,
                // مقاس الشادو الافتراضي 0.5 يعني المربع كله ولكن انا هنا حطيته كده لاني عاوزاه من تحت بس
                showIndicator: true,
                // دي قيمتها الافتراضية ترو بحيث انه دايما يظهر النقط او الشريط لو اخترنا نحطه
                indicatorBgPadding: 10.0,
                // عرض الشريط اللي ورا النقط

                images: [
                  // الكارسول بيقبل صور من نوع ليست فيها كل الصور اللى جابة تنضاف للموقع

                  Image.asset(
                    'images/herfy1.jpg',
                    fit: BoxFit.fill,
                  ),
                  Image.asset(
                    'images/herfy2.jpg',
                    fit: BoxFit.fill,
                  ),
                  Image.asset(
                    'images/herfy3.jpg',
                    fit: BoxFit.fill,
                  ),
                  Image.asset(
                    'images/herfy4.jpg',
                    fit: BoxFit.fill,
                  ),
                ],
              ),
            ),
            SizedBox(
              height: 20,
            ),

            Container(
              child: TextFormField(
                controller: _chaNameControllar,
                decoration: InputDecoration(
                    labelText: "write your challange name here",
                    prefixIcon: Icon(
                      Icons.article_outlined,
                      color: Colors.pink[900],
                    ),
                    labelStyle: TextStyle(
                      color: Colors.pink[900],
                      fontStyle: FontStyle.italic,
                    ),
                    fillColor: Colors.grey[200],
                    filled: true,
                    // prefixIcon: Icon(Icons.store,),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),
                    )
                ),
              ),
            ),

            SizedBox(
              height: 5,
            ),
            Container(
              child: TextFormField(
                minLines: 3,
                maxLines: maxlen,
                autocorrect: true,
                controller: _desCodeControllar,
                decoration: InputDecoration(
                    labelText: "Write your challange desciription here",
                    prefixIcon: Icon(
                      Icons.article_outlined,
                      color: Colors.pink[900],
                    ),
                    labelStyle: TextStyle(
                      color: Colors.pink[900],
                      fontStyle: FontStyle.italic,
                    ),
                    fillColor: Colors.grey[200],
                    filled: true,
                    // prefixIcon: Icon(Icons.store,),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),
            ),


            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text('select date:',  style: TextStyle(fontSize: 20,)),
                Card(
                  elevation: 0,
                  margin: EdgeInsets.symmetric(horizontal: 110, vertical: 5),
                  color: Colors.grey[200],
                  child:ListTile(
                    title: Text(
                        "Date: ${pickedDate.year}, ${pickedDate.month}, ${pickedDate.day}",
                        style: TextStyle(color: Colors.pink[900])
                    ),
                    trailing: Icon(Icons.calendar_today ,color: Colors.pink[900],),
                    onTap: _pickDate,
                  ),),
                Text('select time:',
                  style: TextStyle(fontSize: 20,),
                ),
                Card(
                  elevation:0,
                  margin: EdgeInsets.symmetric(horizontal: 110, vertical: 5),
                  color: Colors.grey[200],
                  child:ListTile(
                    title: Text(
                        "Time:  ${_time.hour} : ${_time.minute} ",
                        style: TextStyle(color: Colors.pink[900])
                    ),
                    trailing: Icon(Icons.access_alarm ,color: Colors.pink[900],),
                    onTap:() { _pickTime();},
                  ),),

              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                RaisedButton(
                  padding: EdgeInsets.only(right: 80,left: 80),
                  color: Colors.pink[900],
                  shape: StadiumBorder(
                    side: BorderSide(
                      color: Colors.pink[900],
                    ),
                  ),
                  onPressed: () {
                    if (_chaNameControllar.text.isEmpty || _desCodeControllar.text.isEmpty){
                      displayToastMassage('Please Enter Valid field', context);
                    }

                    else{
                      createRecord().then((value) {
                        Timer(Duration(seconds: 3), () {
                          Navigator.pop(context);
                          Route route = MaterialPageRoute(builder: (c) => AllCompitionsAdv());
                          Navigator.pushReplacement(context, route);
                        });

                      });
                    }

                    //return AllCompitionsAdv();
                  },
                  child: Text(
                    'Sponser',
                    style: TextStyle(fontSize: 20, color: Colors.white
                      //decoration: new InputDecoration()
                    ),
                  ),
                ),
              ],
            )


          ],
        ) ,
      )

    );
  }
  GeoPoint locations;

  Future<GeoPoint> getStoreLocation(String uid) async {
    final CollectionReference users = firestore.collection('Advertisers');
    DocumentReference documentReference = users.doc(uid);

    await documentReference.get().then((snapshot) {
      locations = snapshot.data()['location'];
    });
    return locations;

  }
  String storename;

  Future<String> getStoreName(String uid) async {
    final CollectionReference users = firestore.collection('Advertisers');
    DocumentReference documentReference =
    firestore.collection('Advertisers').doc(uid);

    await documentReference.get().then((snapshot) {
      storename = snapshot.data()['storeName'];
    });
    return storename;

  }


  Future<void> createRecord() async {
    // displayToastMassage('try1', context);
    var storeLocation = await getStoreLocation(auth.currentUser.uid);
    couponsReference.add({
      'ChalangeDate':
      "${pickedDate.year}, ${pickedDate.month}, ${pickedDate.day} at ${_time.hour}: ${_time.minute}",
      'ChalangeName':_chaNameControllar.text,
      //widget.name,
      "ChallangeDescription": _desCodeControllar.text,
      "price":price,
      //widget.descrption,
      "StoreLocation": storeLocation,
      "StoreName": await getStoreName(auth.currentUser.uid),
      "position": await _someFunction(auth.currentUser.uid),
    }).then((value) {
      // Create a geoFirePoint
      GeoFirePoint center = geo.point(
          latitude: storeLocation.latitude, longitude: storeLocation.longitude);

// get the collection reference or query
      var collectionReference =
      FirebaseFirestore.instance.collection('Participants');

      double radius = 50;
      String field = 'position';

      Stream<List<DocumentSnapshot>> stream = geo
          .collection(collectionRef: collectionReference)
          .within(center: center, radius: radius, field: field);


      stream.listen((event) {
        event.forEach((element) {
          print('There are me ${element.data().toString()}');
          sendNotification(element.get('token'), 'Any thing');
        });
      });
    });
  }

  displayToastMassage(String massag, BuildContext context) {
    Fluttertoast.showToast(
      msg: massag,
    );
  }
  GeoFirePoint point;
  Future<dynamic> _someFunction(String uid) async {
    final CollectionReference users = firestore.collection('Advertisers');
    DocumentReference documentReference = users.doc(uid);

    await documentReference.get().then((DocumentSnapshot snap) {
      var fireBase = snap.data()['location'];
      point = geo.point(
          latitude: double.parse('${fireBase.latitude}'),
          longitude: double.parse('${fireBase.longitude}'));
      print(point.data);
    });
    return point.data;
  }
  Future<void> sendNotification(token, msg) async {
    final data = {
      "notification": {
        "body": "new Challange",
        "title": "EXSB"
      },
      "priority": "high",
      "data": {
        "click_action": "FLUTTER_NOTIFICATION_CLICK",
        "id": "1",
        "status": "done"
      },
      "to": "$token"
    };
    final serverKey =
        'AAAAHws0U9c:APA91bHHOJxFOsCHjUo4fBFSsua_BjHy0ZCvgt2ojFjcL6USwWij7KMMljdfR9KSGuVxV1e0UJE-TLuQ2DBFn7xLDQUUbolnbR1h5tuFslkBJj4pHtXzEeTsa0KBbHudpuM1JgmGQuy-';
    final headers = {
      'content-type': 'application/json',
      'Authorization': 'key=$serverKey'
    };

    BaseOptions options = new BaseOptions(
      connectTimeout: 5000,
      receiveTimeout: 3000,
      headers: headers,
    );

    try {
      final response = await Dio(options).post(postUrl, data: data);

      if (response.statusCode == 200) {
      } else {
        print('notification sending failed');
      }
    } catch (e) {
      print('exception $e');
    }
  }
}
//Write ten words start with the letter(A)
//draw new logo for our restaurant? //draw a logo for our restaurant and win free meale for one month
//who is eat faster than other //this challenge allow participants eat 5 pizza in ten minutes
//eat 10 burger//come to our store and win with this challange
