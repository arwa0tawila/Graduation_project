import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:exsb_app_gp/sighninscreen.dart';
import 'package:flutter/widgets.dart';





class VerifyScreen extends StatefulWidget {
  @override
  _VerifyScreenState createState() => _VerifyScreenState();
}

class _VerifyScreenState extends State<VerifyScreen> {
  final auth = FirebaseAuth.instance;
  User user;
  Timer timer;

  @override
  void initState() {
    user = auth.currentUser;
    user.sendEmailVerification();

    timer = Timer.periodic(Duration(seconds:1), (timer) {
      checkEmailVerified();
    });
    super.initState();
  }

  @override
  void dispose() {
    timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Verify Your Account ', style: TextStyle(color: Colors.pink[900]),),
        centerTitle: true,
        backgroundColor: Colors.orange[200],

      ),
      body: Center(
        child: Container(
          child: Card(
            color: Colors.orange[200],
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15.0),
            ),
            child: Text(
              'An email has been sent to your email ${user.email} please verify to complete  ... Thank You',

              style: TextStyle(color: Colors.pink[900],fontSize: 30 , backgroundColor: Colors.orange[200] , ),),
          )

        )

      ),
    );
  }

  Future<void> checkEmailVerified() async {
    user = auth.currentUser;
    await user.reload();
    if (user.emailVerified) {
      timer.cancel();
      Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => sighninscreen()));
    }
  }
}