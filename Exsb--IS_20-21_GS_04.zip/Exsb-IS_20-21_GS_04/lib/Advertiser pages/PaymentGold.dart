import 'dart:ui';
import 'package:exsb_app_gp/Advertiser%20pages/NotificationsAdv.dart';
import 'package:exsb_app_gp/Advertiser%20pages/Payment200.dart';
import '../drawerADV.dart';
import 'package:flutter/material.dart';

class PaymentGold  extends StatefulWidget {

  @override

  _PaymentGold  createState() => _PaymentGold ();
}

class _PaymentGold extends State<PaymentGold > {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(

          title: Text("Gold Package",style: TextStyle(color: Colors.pink[900]),),
          centerTitle: true,
          backgroundColor: Colors.orange[200],


          actions: [IconButton(icon: Icon(Icons.notifications, color: Colors.pink[900],), onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
              return notificationAdv();
            }));
          })],

        ),
        drawer: drawerADV(),

        body: Container(
          color: Colors.orange[50],
          child:ListView(

            children: [
              SizedBox(height: 20,),

              SizedBox(height: 30,),
              new Image.asset('images/package.png',
                  fit:BoxFit.fill ,width: 100.0,
                  height: 100.0),
              Card(

                elevation: 30,
                margin: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                color: Colors.grey[200],
                child: ListTile(
                  title: Text("Your subscription to the gold package has been activated\n"
                      "\nWorth 200 SAR\n\nCovers the questions section",style: TextStyle(fontSize: 17,color: Colors.pink[900]),),
                  contentPadding: EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                  leading: Icon(Icons.analytics_outlined, size: 30,color: Colors.pink[900],),


                  onTap: (){
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => Payment200()));
                  },

                ),
              ),
              const SizedBox(height: 20.0),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  vertical: 8.0,
                  horizontal: 10.0,
                ),
              ),
            ],
          ) ,
        )

      ),
    );
  }
}