import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class test extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return testState();
  }


}



class testState extends State<test>{
  final firestore = FirebaseFirestore.instance;   //
  FirebaseAuth auth = FirebaseAuth.instance;     //recommend declaring a reference outside the methods

  Future<List> getAllUser() async {

    var users = await firestore.collection('Advertisers').get();


    return users.docs;



  }
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      body:FutureBuilder(
        future: getAllUser(),
        builder: (context, AsyncSnapshot<List> snapshot) {
          if (snapshot.data == null)
            return new Container(
              child: Center(child: new CircularProgressIndicator()),
            );
          else
            return Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              child: ListView.builder(
                itemCount: snapshot.data.length,
                itemBuilder: (context, index) {
                  return Text(snapshot.data[index]['Balance'].toString());
                },
              ),
            );

        },
      ),


    );
  }

}