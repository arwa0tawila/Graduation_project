import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';


class EventsQustion extends StatefulWidget{
  EventsQustion({this.app});
  final FirebaseApp app;
  State<StatefulWidget> createState(){
    return _EventsQustionState();
  }


}

class _EventsQustionState extends State<EventsQustion> {
  DatabaseReference eventQustionref;
  void initState(){
    final FirebaseDatabase database = FirebaseDatabase(app: widget.app);
    eventQustionref= database.reference().child('Qustions Events');
    super.initState();
  }
  final referenceDatase = FirebaseDatabase.instance;
  final EventType = 'Event Type';
  final QustionDeadline = 'Qustion Deadline';
  final QustionPackage = 'Qustion Package';
  final QustionDescription='Qustion Description';
  final Qustion1Controller = TextEditingController();
  final Qustion2Controller = TextEditingController();
  final Qustion3Controller = TextEditingController();
  final Qustion4Controller = TextEditingController();
  @override
  Widget build(BuildContext context){
    final ref = referenceDatase.reference();
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.pink[900],
          title: Text('Question Events Table', textAlign: TextAlign.center,style: TextStyle(color: Colors.orange[200]),),
        ),
        body:SingleChildScrollView(
            child:Column(
              children: [
                Center(
                    child: Container(
                        color: Colors.grey,
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.width,
                        child: Column(
                          children: [
                            Text(
                              EventType ,
                              textAlign: TextAlign.left,
                              style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),

                            ),
                            TextField(
                              controller: Qustion1Controller,
                            ),
                            Text(
                              QustionDescription ,
                              textAlign: TextAlign.left,
                              style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),

                            ),
                            TextField(
                              controller: Qustion4Controller,
                            ),
                            Text(
                              QustionDeadline ,
                              textAlign: TextAlign.left,
                              style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),
                            ),
                            TextField(
                              controller: Qustion2Controller,
                            ),
                            Text(
                              QustionPackage ,
                              textAlign: TextAlign.left,
                              style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),
                            ),
                            TextField(
                              controller: Qustion3Controller,
                            ),
                            FlatButton(
                              color: Colors.pink[900],
                              onPressed: (){
                                ref
                                    .child('Questions Events')
                                    .push()

                                    .set({'Event Type':Qustion1Controller.text,
                                  'Qustion Deadline':Qustion2Controller.text,
                                  'Qustion Package': Qustion3Controller.text,
                                  'Qustion Description': Qustion4Controller.text, }
                                )
                                    .asStream();
                                Qustion1Controller.clear();
                                Qustion2Controller.clear();
                                Qustion3Controller.clear();
                                Qustion4Controller.clear();

                              }, child: Text('Add'), textColor: Colors.orange[200],
                            ),


                          ],
                        )


                    )


                )
              ],
            )

        )
    );

  }
}