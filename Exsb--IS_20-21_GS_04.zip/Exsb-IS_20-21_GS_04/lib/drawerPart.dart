// paticipants drawer
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:exsb_app_gp/sighninscreen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'AboutUs.dart';
import 'Participant pages/AllCompitionsPart.dart';
import 'Participant pages/EditParticipantInformations.dart';
import 'Participant pages/SpesifyLocationPage.dart';

class  OurDrawer extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return state();
  }
}

class state extends State<OurDrawer>{
  final firestore = FirebaseFirestore.instance;   //
  FirebaseAuth auth = FirebaseAuth.instance;//recommend declaring a reference outside the methods
  String userImageUrl = "";
  File _imageFile;
  Future<String> getUserName() async {

    final CollectionReference users = firestore.collection('Advertisers');
    final CollectionReference Pusers = firestore.collection('Participants');

    final String uid = auth.currentUser.uid;

    final Presult = await Pusers.doc(uid).get();
    final result = await users.doc(uid).get();

    if(result.data() != null){
      return result.data()['firstName'] + '\t' + result.data()['lastName']+'\n \n' +  result.data()['email'];}

    if(Presult.data() != null){
      return Presult.data()['firstName'] + '\t' + Presult.data()['lastName']+'\n \n' +  Presult.data()['email'];}
  }
  @override

  Widget build(BuildContext context) {
    double _screenWidth = MediaQuery.of(context).size.width, _screenHeight = MediaQuery.of(context).size.height;

    return Drawer(

      child: ListView(
        padding: EdgeInsets.zero,

        children: <Widget>[
          DrawerHeader(
            decoration: BoxDecoration(
                color: Colors.orange[50],
                shape: BoxShape.rectangle,
                boxShadow:[
                  BoxShadow(
                    color: Colors.orange[200],
                    spreadRadius: 1,
                    blurRadius: 2,
                  )
                ]

            ),


            child: ListView(

              children:
              // <Widget>
              [ InkWell(
                onTap: _selectAndPickImage,
                child: CircleAvatar(
                  radius: _screenWidth * 0.10 ,
                  backgroundColor: Colors.pink[900],
                  backgroundImage: _imageFile==null ? null : FileImage(_imageFile),
                  child: _imageFile == null
                      ? Icon(Icons.add_photo_alternate , size: _screenWidth * 0.10 ,color: Colors.grey,)
                      : null,
                ),
              ),

                FutureBuilder(
                  future: getUserName(),
                  builder: (_ , AsyncSnapshot snapshot){

                    if(snapshot.connectionState == ConnectionState.waiting){
                      return Center( child: CircularProgressIndicator());
                    }
                    return Text(snapshot.data, style: TextStyle(color: Colors.pink[900] , fontSize: 15,), textAlign: TextAlign.center ,);
                  },
                ),
              ],
            ),
          ),
          ListTile(
            title: Text('Home Page',style: TextStyle(color: Colors.pink[900]),), leading: Icon(Icons.home_outlined, color: Colors.pink[900],),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
                return AllCompitionsPart();
              }));
            },
          ),
          ListTile(
            title: Text('Account informations',style: TextStyle(color: Colors.pink[900])),leading: Icon(Icons.info, color: Colors.pink[900]),

            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
                return EditParticipantInformations();
              }));
            },
          ),
          ListTile(
            title: Text('Update your location',style: TextStyle(color: Colors.pink[900])),leading: Icon(Icons.add_location_alt_sharp, color: Colors.pink[900]),

            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
                return SpecifyLocationScreen();
              }));
            },
          ),
          ListTile(
            title: Text('About Us',style: TextStyle(color: Colors.pink[900])),leading: Icon(Icons.person_search, color: Colors.pink[900]),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
                return AboutUs();
              }));
            },
          ),
          ListTile(
            title: Text('Points= 100',style: TextStyle(color: Colors.pink[900])),leading: Icon(Icons.view_compact_sharp, color: Colors.pink[900]),

          ),
          ListTile(
            title: Text('Log Out',style: TextStyle(color: Colors.pink[900])),leading: Icon(Icons.logout, color: Colors.pink[900]),

            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
                return sighninscreen();
              }));
            },
          ),

        ],
      ),

    );
  }



  Future<void> _selectAndPickImage() async {

    var image =await ImagePicker.pickImage(source: ImageSource.gallery);
    setState(() {
      _imageFile = image;
    });
    if(_imageFile == null ){
      BuildContext context;
      displayToastMassage("Please select image", context);
    }
    else {

      uploadToStorage();
    }
  }

  Future<String> uploadToStorage() async {
    String imageFileName  = DateTime.now().millisecondsSinceEpoch.toString();
    var image = firestore.collection('Participants').doc('SYPvPINtAoYe5imREvrQ82SF80s1').update({
      'url': 'any',
    });
    return userImageUrl.toString();


  }

}

displayToastMassage(String massag,  BuildContext context){
  Fluttertoast.showToast(msg: massag,);

}