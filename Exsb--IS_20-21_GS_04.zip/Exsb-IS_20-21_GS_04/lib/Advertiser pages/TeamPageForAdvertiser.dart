import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:exsb_app_gp/drawerADV.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'NotificationsAdv.dart';


class TeamChallangeAdv extends StatefulWidget {
  @override
  _TeamChallangeAdvState createState() => _TeamChallangeAdvState();
}

class _TeamChallangeAdvState extends State {
  @override
  void initState() {
    super.initState();
  }

  final firestore = FirebaseFirestore.instance;   //
  FirebaseAuth auth = FirebaseAuth.instance;     //recommend declaring a reference outside the methods


  @override
  Widget build(BuildContext context) {
    nested() {
      return NestedScrollView(
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return <Widget>[
            SliverAppBar(
              expandedHeight: 200.0,
              floating: false,
              pinned: true,
              flexibleSpace: FlexibleSpaceBar(
                centerTitle: true,
                title: Text(
                  'team Challange',
                  style: TextStyle(
                    color: Colors.pink[900],
                    fontSize: 30.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                background: Image.asset(
                  'images/kk.jpg',
                  fit: BoxFit.cover,
                ),
              ),
              backgroundColor: Colors.orange[200],
              actions: [IconButton(icon: Icon(Icons.notifications, color: Colors.pink[900],), onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
                  return notificationAdv();
                }));
              })],
            ),
          ];
        },
        body: Container(
          child: ListView(
            children: <Widget>[
              Card(
                elevation: 8.0,
                margin:
                new EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
                child: Container(
                  decoration: BoxDecoration(color: Colors.pink[900]),
                  child: ListTile(
                    contentPadding:
                    EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                    leading: Container(
                      padding: EdgeInsets.only(right: 12.0),
                      decoration: new BoxDecoration(
                          border: new Border(
                              right: new BorderSide(
                                  width: 1.0, color: Colors.white24))),
                      child: Icon(Icons.question_answer, color: Colors.white),
                    ),
                    title: Text(
                      "challange1",
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),

                    subtitle: Expanded(
                      flex: 4,
                      child: Padding(
                          padding: EdgeInsets.only(left: 30.0),
                          child: Text('by ...',
                              style: TextStyle(color: Colors.brown))),
                    ),

                    trailing: Icon(Icons.keyboard_arrow_right,
                        color: Colors.white, size: 30.0),
                    onTap: () {},
                  ),
                ),
              ),
              Card(
                elevation: 8.0,
                margin:
                new EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
                child: Container(
                  decoration: BoxDecoration(color: Colors.pink[900]),
                  child: ListTile(
                    contentPadding:
                    EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                    leading: Container(
                      padding: EdgeInsets.only(right: 12.0),
                      decoration: new BoxDecoration(
                          border: new Border(
                              right: new BorderSide(
                                  width: 1.0, color: Colors.white24))),
                      child: Icon(Icons.question_answer, color: Colors.white),
                    ),
                    title: Text(
                      "Challange2",
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),

                    subtitle: Expanded(
                      flex: 4,
                      child: Padding(
                          padding: EdgeInsets.only(left: 30.0),
                          child: Text('by ...',
                              style: TextStyle(color: Colors.brown))),
                    ),

                    trailing: Icon(Icons.keyboard_arrow_right,
                        color: Colors.white, size: 30.0),
                    onTap: () {},
                  ),
                ),
              ),
              Card(
                elevation: 8.0,
                margin:
                new EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
                child: Container(
                  decoration: BoxDecoration(color: Colors.pink[900]),
                  child: ListTile(
                    contentPadding:
                    EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                    leading: Container(
                      padding: EdgeInsets.only(right: 12.0),
                      decoration: new BoxDecoration(
                          border: new Border(
                              right: new BorderSide(
                                  width: 1.0, color: Colors.white24))),
                      child: Icon(Icons.question_answer, color: Colors.white),
                    ),
                    title: Text(
                      "Challange3",
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),

                    subtitle: Expanded(
                      flex: 4,
                      child: Padding(
                          padding: EdgeInsets.only(left: 30.0),
                          child: Text('by ...',
                              style: TextStyle(color: Colors.brown))),
                    ),

                    trailing: Icon(Icons.keyboard_arrow_right,
                        color: Colors.white, size: 30.0),
                    onTap: () {},
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      drawer: drawerADV(),

      body: nested(),
    );
  }
}
