import 'dart:async';
import './sighninscreen.dart';
import 'package:flutter/material.dart';
class welcome extends StatefulWidget {
  @override
  _welcomeState createState() => _welcomeState();
}

class _welcomeState extends State<welcome> {
  @override
  Widget build(BuildContext context) {

    Timer(

        Duration(seconds: 3),
            () =>
            Navigator.of(context).pushReplacement(MaterialPageRoute(
                builder: (BuildContext context) => sighninscreen())));


    var assetsImage = new AssetImage(
        'images/exsbLogo.png'); //<- Creates an object that fetches an image.
    var image = new Image(
        image: assetsImage,
        height:300); //<- Creates a widget that displays an image.

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Container(
          child: new Center(
            child: image,
          ),
        ), //<- place where the image appears
      ),
    );
  }
}
