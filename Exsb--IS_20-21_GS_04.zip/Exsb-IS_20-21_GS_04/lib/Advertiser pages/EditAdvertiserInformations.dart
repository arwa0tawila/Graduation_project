import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:exsb_app_gp/drawerADV.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import '../sighninscreen.dart';
import 'NotificationsAdv.dart';

class EditAdvertiserInformations extends StatefulWidget {
  @override
  _EditAdvertiserInformationsState createState() => _EditAdvertiserInformationsState();
}

class _EditAdvertiserInformationsState extends State<EditAdvertiserInformations> {
  TextEditingController _firstNameField = TextEditingController();
  TextEditingController _lastNameField = TextEditingController();
  TextEditingController _phoneNumberField = TextEditingController();
  String _email, _password;

  final firestore = FirebaseFirestore.instance;   //
  FirebaseAuth auth = FirebaseAuth.instance;//recommend declaring a reference outside the methods

  String newPassword;
  String Fname1;
  String FirstName;

  String newpassword; //recommend declaring a reference outside the methods
  Future<String> getFirstName() async {
    final CollectionReference Pusers = firestore.collection('Advertisers');
    final String uid = auth.currentUser.uid;
    final Presult = await Pusers.doc(uid).get();
    if (Presult.data() != null) {
      FirstName = Presult.data()['firstName'].toString();
    }

    setState(() {
      Fname1 = FirstName;
    });
  }

  String Lname1;
  String lasttName;

  Future<String> getLastName() async {
    final CollectionReference Pusers = firestore.collection('Advertisers');
    final String uid = auth.currentUser.uid;
    final Presult = await Pusers.doc(uid).get();
    if (Presult.data() != null) {
      lasttName = Presult.data()['lastName'].toString();
    }

    setState(() {
      Lname1 = lasttName;
    });
  }

  String Phone1;
  String PhoneNum;

  Future<String> getPhone() async {
    final CollectionReference Pusers = firestore.collection('Advertisers');
    final String uid = auth.currentUser.uid;
    final Presult = await Pusers.doc(uid).get();
    if (Presult.data() != null) {
      PhoneNum = Presult.data()['phoneNumber'].toString();
    }

    setState(() {
      Phone1 = PhoneNum;
    });
  }

  String Pass1;
  String PasswordNum;

  Future<String> getPass() async {
    final CollectionReference Pusers = firestore.collection('Advertisers');
    final String uid = auth.currentUser.uid;
    final Presult = await Pusers.doc(uid).get();
    if (Presult.data() != null) {
      PasswordNum = Presult.data()['Password'].toString();
    }

    setState(() {
      Pass1 = PasswordNum;
    });
  }
  @override
  void initState() {
    getFirstName();
    getLastName();
    getPhone();
    getPass();
    super.initState();
  }



  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('Edit Advertiser Informations', style: TextStyle(color: Colors.pink[900])),
          centerTitle: true,
          backgroundColor: Colors.orange[200],

          actions: [IconButton(icon: Icon(Icons.notifications, color: Colors.pink[900],), onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
              return notificationAdv();
            }));
          })],

        ),
        drawer: drawerADV(),

        body: Container(
          color: Colors.orange[50],
          child: ListView(
            padding: EdgeInsets.all(10),
            children: [
              Card(
                color: Colors.orange[50],
                child: Text('Chang your information here \n '
                    'Note : \n Change information you want and let other as same ' , textAlign: TextAlign.center ,style: TextStyle(fontSize: 25 ,color: Colors.pink[900],),),

              ),

              SizedBox(height: 50,),

              SizedBox(height: 10,width: 20,),
              TextFormField(
                controller: _firstNameField,
                decoration: InputDecoration(
                    labelText: Fname1,
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.person, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),
              SizedBox(height: 10,width: 20,),
              TextFormField(
                controller: _lastNameField,
                decoration: InputDecoration(
                    labelText: Lname1,
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.account_box, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),

              SizedBox(height: 10,width: 20,),
              TextFormField(
                controller: _phoneNumberField,
                decoration: InputDecoration(
                    labelText: Phone1,
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.phone, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),


                    )
                ),
              ),


              SizedBox(height: 50,width: 20,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  RaisedButton(

                    padding: EdgeInsets.only(right: 10,left: 10),
                    color: Colors.pink[900],
                    shape:   RoundedRectangleBorder(
                      side: BorderSide(

                        color: Colors.black54,
                        width: 1.0,
                      ),
                      borderRadius: BorderRadius.circular(50),
                    ),
                    //elevation: ,
                    onPressed: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => ResetScreen()),
                      );

                    },
                    child: Text('Change Password', style: TextStyle(
                      fontSize: 25,
                      color: Colors.white,

                    ),),
                  ),
                ],
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  RaisedButton(
                    padding: EdgeInsets.only(right: 80,left: 80),

                    color: Colors.pink[900],
                    shape:   StadiumBorder(
                      side: BorderSide(
                        color: Colors.pink[900],
                        width: 1.0,
                      ),
                    ),
                    //elevation: ,
                    onPressed:(){
                      if (_phoneNumberField.text.isEmpty) {
                        displayToastMassage('Add Your PhoneNumber ', context);
                      }
                      else if (_phoneNumberField.text.length != 10) {
                        displayToastMassage(
                            'Phone Number Must Be 10 Numbers', context);
                      }

                      else if (_firstNameField.text.isEmpty) {
                        displayToastMassage('Add Your FirstName ', context);
                      }

                      else {
                        updateUserData();
                      }
                    },
                    child: Text('Save', style: TextStyle(
                        fontSize: 25,
                        color: Colors.white
                    ),),
                  ),
                ],
              )

            ],
          ),
        )

      ),
    );
  }
  bool loading = false;


  updateUserData() async {
    final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
    User firebaseUser;
    firebaseUser = _firebaseAuth.currentUser;
    if (_firebaseAuth.currentUser != null) {
      auth.currentUser.updatePassword(newpassword).then((_) {});

      FirebaseFirestore.instance.collection("Advertisers").doc(
          firebaseUser.uid).update({
        "firstName": _firstNameField.value.text.trim(),
        "lastName": _lastNameField.value.text.trim(),
        "phoneNumber": _phoneNumberField.value.text.trim(),
      });
      SetOptions(merge: true);

    }

  }
}
displayToastMassage(String massag,  BuildContext context){
  Fluttertoast.showToast(msg: massag,);

}
