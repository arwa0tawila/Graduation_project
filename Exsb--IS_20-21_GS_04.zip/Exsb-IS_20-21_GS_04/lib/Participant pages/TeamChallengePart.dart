import 'package:flutter/material.dart';
import '../drawerPart.dart';
import 'NotifcationsPart.dart';


class ListTeamChallange extends StatefulWidget {
  @override
  _ListTeamChallangeState createState() => _ListTeamChallangeState();
}

class _ListTeamChallangeState extends State {
  @override
  void initState() {
    super.initState();
  }



  @override
  Widget build(BuildContext context) {
    nested() {
      return NestedScrollView(
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return <Widget>[
            SliverAppBar(
              expandedHeight: 200.0,
              floating: false,
              pinned: true,
              flexibleSpace: FlexibleSpaceBar(
                centerTitle: true,
                title: Text(
                  'team Challange',
                  style: TextStyle(
                    color: Colors.pink[900],
                    fontSize: 30.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                background: Image.asset(
                  'images/kk.jpg',
                  fit: BoxFit.cover,
                ),
              ),
              backgroundColor: Colors.orange[200],
              leading: IconButton(
                  onPressed: () {
                  },
                  icon: Icon(
                    Icons.menu,
                    color: Colors.pink[900],
                  )),
              actions: [IconButton(icon: Icon(Icons.notifications, color: Colors.pink[900],), onPressed: (){
                Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
                  return notificationPart();
                }));
              })],
            ),
          ];
        },
        body: Container(
          child: ListView(
            children: <Widget>[
              Card(
                elevation: 8.0,
                margin:
                new EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
                child: Container(
                  decoration: BoxDecoration(color: Colors.pink[900]),
                  child: ListTile(
                    contentPadding:
                    EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                    leading: Container(
                      padding: EdgeInsets.only(right: 12.0),
                      decoration: new BoxDecoration(
                          border: new Border(
                              right: new BorderSide(
                                  width: 1.0, color: Colors.white24))),
                      child: Icon(Icons.question_answer, color: Colors.white),
                    ),
                    title: Text(
                      "challange1",
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),

                    subtitle: Expanded(
                      flex: 4,
                      child: Padding(
                          padding: EdgeInsets.only(left: 30.0),
                          child: Text('by ...',
                              style: TextStyle(color: Colors.brown))),
                    ),

                    trailing: Icon(Icons.keyboard_arrow_right,
                        color: Colors.white, size: 30.0),
                    onTap: () {},
                  ),
                ),
              ),
              Card(
                elevation: 8.0,
                margin:
                new EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
                child: Container(
                  decoration: BoxDecoration(color: Colors.pink[900]),
                  child: ListTile(
                    contentPadding:
                    EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                    leading: Container(
                      padding: EdgeInsets.only(right: 12.0),
                      decoration: new BoxDecoration(
                          border: new Border(
                              right: new BorderSide(
                                  width: 1.0, color: Colors.white24))),
                      child: Icon(Icons.question_answer, color: Colors.white),
                    ),
                    title: Text(
                      "Challange2",
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),

                    subtitle: Expanded(
                      flex: 4,
                      child: Padding(
                          padding: EdgeInsets.only(left: 30.0),
                          child: Text('by ...',
                              style: TextStyle(color: Colors.brown))),
                    ),

                    trailing: Icon(Icons.keyboard_arrow_right,
                        color: Colors.white, size: 30.0),
                    onTap: () {},
                  ),
                ),
              ),
              Card(
                elevation: 8.0,
                margin:
                new EdgeInsets.symmetric(horizontal: 10.0, vertical: 6.0),
                child: Container(
                  decoration: BoxDecoration(color: Colors.pink[900]),
                  child: ListTile(
                    contentPadding:
                    EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                    leading: Container(
                      padding: EdgeInsets.only(right: 12.0),
                      decoration: new BoxDecoration(
                          border: new Border(
                              right: new BorderSide(
                                  width: 1.0, color: Colors.white24))),
                      child: Icon(Icons.question_answer, color: Colors.white),
                    ),
                    title: Text(
                      "Challange3",
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold),
                    ),

                    subtitle: Expanded(
                      flex: 4,
                      child: Padding(
                          padding: EdgeInsets.only(left: 30.0),
                          child: Text('by ...',
                              style: TextStyle(color: Colors.brown))),
                    ),

                    trailing: Icon(Icons.keyboard_arrow_right,
                        color: Colors.white, size: 30.0),
                    onTap: () {},
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      drawer: OurDrawer(),
      body: nested(),
    );
  }
}
