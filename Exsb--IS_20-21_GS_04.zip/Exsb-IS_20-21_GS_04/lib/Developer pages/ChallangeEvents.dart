import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';


class EventsChallenge extends StatefulWidget{
  EventsChallenge({this.app});
  final FirebaseApp app;
  State<StatefulWidget> createState(){
    return _EventsChallengeState();
  }


}

class _EventsChallengeState extends State<EventsChallenge> {
  DatabaseReference eventChallengeref;
  void initState(){
    final FirebaseDatabase database = FirebaseDatabase(app: widget.app);
    eventChallengeref= database.reference().child('Challenge Events');
    super.initState();
  }
  final referenceDatase = FirebaseDatabase.instance;
  final ChallengeType = 'Event Type';
  final ChallengeDeadline = 'Challenge Deadline';
  final ChallengePackage = 'Challenge Package';
  final ChallengeDescription='Challenge Description';
  final Challenge1Controller = TextEditingController();
  final Challenge2Controller = TextEditingController();
  final Challenge3Controller = TextEditingController();
  final Challenge4Controller = TextEditingController();
  @override
  Widget build(BuildContext context){
    final ref = referenceDatase.reference();
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.pink[900],
          title: Text('Challenge Events Table', textAlign: TextAlign.center,style: TextStyle(color: Colors.orange[200]),),
        ),
        body:SingleChildScrollView(
            child:Column(
              children: [
                Center(
                    child: Container(
                        color: Colors.grey,
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.width,
                        child: Column(
                          children: [
                            Text(
                              ChallengeType ,
                              textAlign: TextAlign.left,
                              style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),

                            ),
                            TextField(
                              controller: Challenge1Controller,
                            ),
                            Text(
                              ChallengeDescription ,
                              textAlign: TextAlign.left,
                              style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),

                            ),
                            TextField(
                              controller: Challenge4Controller,
                            ),
                            Text(
                              ChallengeDeadline ,
                              textAlign: TextAlign.left,
                              style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),
                            ),
                            TextField(
                              controller: Challenge2Controller,
                            ),
                            Text(
                              ChallengePackage ,
                              textAlign: TextAlign.left,
                              style: TextStyle(fontSize: 25,fontWeight: FontWeight.bold),
                            ),
                            TextField(
                              controller: Challenge3Controller,
                            ),
                            FlatButton(
                              color: Colors.pink[900],
                              onPressed: (){
                                ref
                                    .child('Challenge Events')
                                    .push()

                                    .set({'Event Type':Challenge1Controller.text,
                                  'Challenge Deadline':Challenge2Controller.text,
                                  'Challenge Package': Challenge3Controller.text,
                                  'Challenge Description': Challenge4Controller.text, }
                                )
                                    .asStream();
                                Challenge1Controller.clear();
                                Challenge2Controller.clear();
                                Challenge3Controller.clear();
                                Challenge4Controller.clear();

                              }, child: Text('Add'), textColor: Colors.orange[200],
                            ),


                          ],
                        )


                    )


                )
              ],
            )

        )
    );

  }
}