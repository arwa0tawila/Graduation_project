import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:exsb_app_gp/drawerADV.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geoflutterfire/geoflutterfire.dart';

class addpackage extends StatefulWidget {
  addpackage({this.app});
  final FirebaseApp app;
  State<StatefulWidget> createState() {
    return addpackageState();
  }}

class addpackageState extends State<addpackage> {

  final firestore = FirebaseFirestore.instance;   //
  FirebaseAuth auth = FirebaseAuth.instance;     //recommend declaring a reference outside the methods
  TextEditingController _addpackagenameControllar = TextEditingController();
  TextEditingController _addpackagedescriptionControllar = TextEditingController();
  TextEditingController _addpriceControllar = TextEditingController();

  Geoflutterfire geo = Geoflutterfire();

  Future<List> getAllCoupons() async {

    var addpackage = await firestore.collection('addpackage').get();

    return addpackage.docs;
  }
  @override

  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text("Add Package" , style: TextStyle(color:Colors.pink[900]),),
        backgroundColor: Colors.orange[200],

        centerTitle: true,

        actions: [IconButton(icon: Icon(Icons.notifications, color: Colors.pink[900],), onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
          }));
        })],
      ),
      drawer: drawerADV(),
      body: ListView(
        //  scrollDirection: Axis.vertical,
        children: [

          Container(
            height: 200.0,
            width: double.infinity,
            child: Carousel(
              boxFit: BoxFit.fill,
              autoplay: true,
              autoplayDuration: Duration(seconds: 5),
              animationCurve: Curves.fastOutSlowIn,
              animationDuration: Duration(milliseconds: 1000),
              dotSize: 8.0,
              dotSpacing: 10,
              dotColor: Colors.black,
              dotIncreasedColor: Color(
                  0xFFFF335C),
              dotBgColor: Colors.orange[200].withOpacity(0.5),
              dotPosition: DotPosition
                  .bottomCenter,
              dotVerticalPadding:
              00.0,
              borderRadius: true,
              radius: Radius.circular(40),
              overlayShadow: true,
              overlayShadowColors: Colors.brown,
              overlayShadowSize:
              0.2,
              showIndicator:
              true,
              indicatorBgPadding: 10.0,
              images: [
                Image.asset('images/ad.jpg',fit: BoxFit.fill,),
                Image.asset('images/ads.jpg',fit: BoxFit.fill,),
                Image.asset('images/adv.jpg',fit: BoxFit.fill,),
                Image.asset('images/add.jpg',fit: BoxFit.fill,),
                Image.asset('images/advs.jpg',fit: BoxFit.fill,),
              ],),),

          // -------------------------------Best-----------------------------------
          Container(
            padding: EdgeInsets.all(5),
            child: Text("Add Package", style: TextStyle(fontSize: 30, color: Colors.pink[900],
            ),
            ),),
          Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.all(5),
            child: ListView(

              scrollDirection: Axis.vertical,


              children: [

                Container(

                  height: MediaQuery.of(context).size.height,
                  width: MediaQuery.of(context).size.width,
                  color: Colors.white,
                  child: ListView(
                    children: [
                      Container(
                        child: TextFormField(
                          controller: _addpackagenameControllar ,
                          decoration: InputDecoration(
                              labelText: "package name",
                              fillColor: Colors.white,
                              filled: true,
                              prefixIcon: Icon(Icons.chevron_right_outlined,),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                              )
                          ),
                        ),
                      ),


                      Container(
                        child: TextFormField(
                          controller: _addpackagedescriptionControllar,
                          decoration: InputDecoration(
                              labelText: "package description",
                              fillColor: Colors.white,
                              filled: true,
                              prefixIcon: Icon(Icons.crop_free,),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                              )
                          ),
                        ),
                      ),

                      Container(
                        child: RaisedButton(
                          color: Colors.pink[900],
                          shape:   StadiumBorder(
                            side: BorderSide(
                              color: Colors.pink[900],

                            ),
                          ),
                          //elevation: ,
                          onPressed:(){
                            if (_addpackagenameControllar.text.isEmpty || _addpackagedescriptionControllar.text.isEmpty){
                              displayToastMassage('Please Enter Required information', context);
                            }else{
                              createRecord();
                            }
                          },
                          child: Text('Save', style: TextStyle(
                              fontSize: 20,
                              color: Colors.white
                          ),),
                        ),

                      ),


                      StreamBuilder(stream: addpackageReference.snapshots(),builder: (_,AsyncSnapshot<QuerySnapshot> snapshot)
                      {
                        if(snapshot.hasData){
                          return Container(
                              height: 500,
                              child: ListView.builder(
                                itemCount: snapshot.data.docs.length,
                                itemBuilder: (context, index) {

                                  var doc = snapshot.data.docs[index].data;
                                  return ListTile(

                                    title: Text("package name: "+snapshot.data.docs[index]['packegename'].toString(),
                                        style: TextStyle(
                                            fontSize: 20.0, fontWeight: FontWeight.bold, color: Colors.deepOrangeAccent[200])),
                                    subtitle:Text("package description: "+snapshot.data.docs[index]['description'].toString(),
                                        style: TextStyle(
                                            fontSize: 20.0, fontWeight: FontWeight.bold, color: Colors.pink[900])),

                                    trailing: IconButton(icon: Icon(Icons.delete, color: Colors.pink[900],) ,
                                      onPressed: () {
                                        snapshot.data.docs[index]
                                            .reference
                                            .delete();
                                      }, ),
                                  );
                                  //);
                                },
                              )
                          );
                        }else
                          return new Container(
                            child: Center(child: new CircularProgressIndicator()),
                          );
                      })

                    ],

                  ),
                ),
//print("-------------------------------------------------------------------"),

              ],
            ),
          ),

        ],
      ),
    );
  }

  Future<GeoPoint> getStoreLocation(String uid) async {
    final CollectionReference users = firestore.collection('Advertisers');
    DocumentReference documentReference = users.doc(uid);
    GeoPoint locations;
    await documentReference.get().then((snapshot) {
      locations = snapshot.data()['location'];
    });
    return locations;
  }
  Future<void> createRecord() async {

    addpackageReference.add(
        {
          'packegename': _addpackagenameControllar.text,
          'description': _addpackagedescriptionControllar.text,

        });

    _addpackagenameControllar.clear();
    _addpackagedescriptionControllar.clear();

    displayToastMassage('Package  has been added sucsseflly', context);

  }
  final addpackageReference =  FirebaseFirestore.instance.collection("addpackage");

  Future<void> Deletecoupon(String docID) async {
    String s=addpackageReference.doc().id.toString();
    print(s);
    addpackageReference.doc(docID).delete();

    displayToastMassage('Package has been deleted sucsseflly', context);


  }

  Future<dynamic> _someFunction(String uid) async {
    final CollectionReference users = firestore.collection('Advertisers');
    DocumentReference documentReference = users.doc(uid);
    GeoFirePoint point;
    await documentReference.get().then((DocumentSnapshot snap) {
      var fireBase = snap.data()['location'];
      point = geo.point(
          latitude: double.parse('${fireBase.latitude}'),
          longitude: double.parse('${fireBase.longitude}'));
      print(point.data);
    });
    return point.data;
  }
}

displayToastMassage(String massag,  BuildContext context){
  Fluttertoast.showToast(msg: massag,);

}