import 'package:exsb_app_gp/Participant%20pages/VerifyScreen.dart';
import 'package:exsb_app_gp/welcomeScreen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart';
import 'package:location/location.dart';


class CreatAccountForAdvertiser extends StatefulWidget {
  @override
  _CreatAccountForAdvertiserState createState() => _CreatAccountForAdvertiserState();
}

class _CreatAccountForAdvertiserState extends State<CreatAccountForAdvertiser> {

  TextEditingController _firstNameField = TextEditingController();
  TextEditingController _lastNameField = TextEditingController();
  TextEditingController _emailAddressField = TextEditingController();
  TextEditingController _passwordField = TextEditingController();
  TextEditingController _phoneNumberField = TextEditingController();
  TextEditingController _commertialNumberField = TextEditingController();
  TextEditingController _storeNameField = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  int  Balance = 2000 ;
  String _email, _password;
  FirebaseAuth auth = FirebaseAuth.instance;


  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('Creat Account For Advertiser', style: TextStyle(color: Colors.pink[900])),
          centerTitle: true,
          backgroundColor: Colors.orange[200],

        ),
        body: Container(
          color: Colors.orange[50],
          child: ListView(
            key: _formKey,
            padding: EdgeInsets.all(10),
            children: [

              SizedBox(height: 50,),

              SizedBox(height: 10,width: 20,),
              TextFormField(
                controller: _firstNameField ,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                    labelText: "First Name ",
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.person, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),
              SizedBox(height: 10,width: 20,),
              TextFormField(
                controller: _lastNameField,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                    labelText: "Last Name ",
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.account_box, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),
              SizedBox(height: 10,width: 20,),
              TextFormField(
                controller: _emailAddressField,
                keyboardType: TextInputType.emailAddress,
                onChanged: (value) {
                  setState(() {
                    _email = value.trim();
                  });
                },
                decoration: InputDecoration(
                    hintText: "something@gmail.com",
                    labelText: "Email Address ",
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.mail, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),
              // TextFormField(


              SizedBox(height: 10,width: 20,),
              TextFormField(
                onChanged: (value) {
                  setState(() {
                    _password = value.trim();
                  });
                },
                controller: _passwordField ,
                obscureText: true,
                obscuringCharacter: "*",
                decoration: InputDecoration(
                    labelText: "Password",
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.vpn_key, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),

              SizedBox(height: 10,width: 20,),
              TextFormField(
                controller: _phoneNumberField,
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                    hintText: "0501234567",
                    labelText: "Phone Number",
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.phone, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),


                    )
                ),
              ),



              SizedBox(height: 10,width: 20,),
              TextFormField(
                controller: _commertialNumberField,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                    labelText: "Commertial Number",
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.ballot_outlined, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),

              ),

              SizedBox(height: 10,width: 20,),
              TextFormField(
                controller: _storeNameField,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                    labelText: "Store Name ",
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.store_mall_directory_rounded, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),

              Text(' Specify Your Location automatically : ', style: TextStyle(fontSize: 20, color: Colors.pink[900], ),),
              SizedBox(height: 30,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  RaisedButton(
                    padding: EdgeInsets.only(right: 80,left: 80),
                    color: Colors.pink[900],
                    shape:   StadiumBorder(
                      side: BorderSide(
                        color: Colors.black54,
                        width: 1.0,
                      ),
                    ),
                    //elevation: ,
                    onPressed:(){
                      checkLocationInDevise();
                    },
                    child: Text('Save', style: TextStyle(
                        fontSize: 25,
                        color: Colors.white
                    ),),
                  ),
                ],
              ),



              SizedBox(height: 30,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  RaisedButton(
                    padding: EdgeInsets.only(right: 25,left: 25),
                    color: Colors.pink[900],
                    shape:   StadiumBorder(
                      side: BorderSide(
                        color: Colors.pink[900],
                        width: 1.0,
                      ),
                    ),
                    //elevation: ,
                    onPressed: (){

                      //validation
                      _firstNameField.text.isNotEmpty;
                      _lastNameField.text.isNotEmpty;
                      _emailAddressField.text.isNotEmpty;
                      _passwordField.text.isNotEmpty;
                      _phoneNumberField.text.isNotEmpty;
                      _commertialNumberField.text.isNotEmpty;
                      _storeNameField.text.isNotEmpty;

                      if (_firstNameField.text.isEmpty || _lastNameField.text.isEmpty
                          || _emailAddressField.text.isEmpty || _passwordField.text.isEmpty
                          || _phoneNumberField.text.isEmpty || _commertialNumberField.text.isEmpty
                          || _storeNameField.text.isEmpty ){
                        displayToastMassage('All input is required', context);
                      }


                      if (! _emailAddressField.text.contains("@gmail.com")){
                        displayToastMassage('Email address should be @gmail.com', context);
                      }

                      else if ( _phoneNumberField.text.length != 10) {
                        displayToastMassage('Phone Number Must Be 10 Numbers', context);
                      }

                      else if ( _passwordField.text.length<6) {
                        displayToastMassage('password must be more than 7 character', context);
                      }
                      else{
                        registerUser();
                      }

                      return welcome();

                    },
                    child: Text('Create Account', style: TextStyle(
                        fontSize: 25,
                        color: Colors.white
                    ),),
                  ),
                ],
              )

            ],
          ),
        )

      ),
    );
  }



  // انستانس من الفاير
  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  void registerUser() async{
    User firebaseUser;
    await _firebaseAuth.createUserWithEmailAndPassword
      (email: _emailAddressField.text.trim(),
      password: _passwordField.text.trim(),
    ).then((firebaseAuth) {
      firebaseUser = firebaseAuth.user;
    }).catchError((error){
      Navigator.pop(context);
    });

    if(firebaseUser != null){
      saveUserInfoToFireStore(firebaseUser).then((value){
        Navigator.pop(context);
        Route route = MaterialPageRoute(builder: (c) => VerifyScreen());
        Navigator.pushReplacement(context, route);
      });

    }
  }
  Future saveUserInfoToFireStore(User fUser) async {
    FirebaseFirestore.instance.collection("Advertisers").doc(fUser.uid).set({
      "firstName": _firstNameField.text.trim(),
      "lastName": _lastNameField.text.trim(),
      "email" : fUser.email,
      "Password" : _passwordField.text.trim(),
      "phoneNumber" : _phoneNumberField.text.trim(),
      "commertialNumber" : _commertialNumberField.text.trim(),
      "storeName" : _storeNameField.text.trim(),
      "Balance" : Balance,
      "location": new GeoPoint(0,0),
    });






  }



  final firestore = FirebaseFirestore.instance;   //
  bool _serviceEnabled;
  PermissionStatus _permissionGranted;
  LocationData _location;
  final databaseReference = FirebaseDatabase.instance.reference();
  CollectionReference location_ref = FirebaseFirestore.instance.collection('Advertisers');

  Future<void> checkLocationInDevise() async {// عشاان نعرف هل خدمة GPS مفعلة في البرنامج او لا

    Location location = new Location();
    _serviceEnabled = await location.serviceEnabled();

    if (_serviceEnabled)
    {

      // print('gps enabled');
      _permissionGranted = await location.hasPermission();
      if(_permissionGranted == PermissionStatus.granted)
      {
        print("------------------------------0000000-----------");
        Location location = new Location();
        location.onLocationChanged.listen((LocationData currentLocation) {
          // Use current location -MUz-fJm-2B9vi9QlLJA
          location_ref.doc(auth.currentUser.uid).update({
            'location': GeoPoint(currentLocation.latitude, currentLocation.longitude)
          }).asStream();
        });


        print("------------------------------11111------------");
        //    });

      }else
      {
        _permissionGranted = await location.requestPermission();// requst
        if(_permissionGranted == PermissionStatus.granted )
        {
          Location location = new Location();
          location.onLocationChanged.listen((LocationData currentLocation) {
            location_ref.doc(auth.currentUser.uid).update({
              'location': GeoPoint(currentLocation.latitude, currentLocation.longitude)
            }).asStream();
          });

        }else {
          SystemNavigator.pop();
        }

      }

    }else {
      _serviceEnabled = await location.requestService();
      if (_serviceEnabled){
        _permissionGranted = await location.hasPermission();
        if(_permissionGranted == PermissionStatus.granted)
        {

          Location location = new Location();
          location.onLocationChanged.listen((LocationData currentLocation) {
            location_ref.doc(auth.currentUser.uid).update({
              'location': GeoPoint(currentLocation.latitude, currentLocation.longitude)
            }).asStream();
          });

        }else
        {
          SystemNavigator.pop();
        }
      }

    }
  }
}
displayToastMassage(String massage,  BuildContext context){
  Fluttertoast.showToast(msg: massage,);



}