import 'package:carousel_pro/carousel_pro.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:geoflutterfire/geoflutterfire.dart';
import '../drawerPart.dart';
import 'NotifcationsPart.dart';


class listchallange extends StatefulWidget {
  @override
  _listchallangeState createState() => _listchallangeState();
}

class _listchallangeState extends State {
  Geoflutterfire geo = Geoflutterfire();
  GeoFirePoint myLocation;

  Future<GeoFirePoint> _getUserLocation() async {
    final CollectionReference par = firestore.collection("Participants");
    DocumentReference documentReference = par.doc(auth.currentUser.uid);
    GeoFirePoint point0;
    await documentReference.get().then((DocumentSnapshot snap) {
      if (snap.exists) {
        var fireBase = snap.data()['location'];
        point0 = geo.point(
            latitude: double.parse('${fireBase.latitude}'),
            longitude: double.parse('${fireBase.longitude}'));
      }
    });
    setState(() {
      myLocation = point0;
    });
  }

  Stream<List<DocumentSnapshot>> getDocumentNearB(GeoFirePoint userLocation) {
    double radius = 50;
    String field = 'position';
    var docRef = firestore.collection("ChallangesPart");
    Stream<List<DocumentSnapshot>> query = geo
        .collection(collectionRef: docRef)
        .within(
        center: userLocation, //await someFunction1(auth.currentUser.uid)/,
        radius: radius,
        field: field,
        strictMode: true);

    return query;
  }

  @override
  void initState() {
    _getUserLocation();
    print('My location --> ${myLocation?.data}');
    super.initState();
  }

  final ChallangesPartReference =
  FirebaseFirestore.instance.collection("ChallangesPart");
  final ParticipantsInChallenge =
  FirebaseFirestore.instance.collection("ParticipantsInChallenge");
  final firestore = FirebaseFirestore.instance; //
  FirebaseAuth auth = FirebaseAuth
      .instance; //recommend declaring a reference outside the methods

  Future<List> getAllPartChallanges() async {
    var ChallangesPart = await firestore.collection('ChallangesPart').get();

    return ChallangesPart.docs;
  }

  //
  checkIfUserAlrdyParticipated(reference) async {}

  Future<String> getUserName(String uid) async {
    DocumentReference documentReference =
    firestore.collection('Participants').doc(uid);
    String Username;
    await documentReference.get().then((snapshot) {
      Username = snapshot.data()['firstName'];
    });
    return Username;
  }

  Future<String> getUserPhone(String uid) async {
    DocumentReference documentReference =
    firestore.collection('Participants').doc(uid);
    String phoneNumberUser;
    await documentReference.get().then((snapshot) {
      phoneNumberUser = snapshot.data()['phoneNumber'];
    });
    return phoneNumberUser;
  }

  Future<String> getUserEmail(String uid) async {
    DocumentReference documentReference =
    firestore.collection('Participants').doc(uid);
    String Uemail;
    await documentReference.get().then((snapshot) {
      Uemail = snapshot.data()['email'];
    });
    return Uemail;
  }

  Future<void> ParticipateAtChallanges(String Challange1_ID) async {
    print(Challange1_ID);
    print(getUserEmail(auth.currentUser.uid));
    String userEmail = getUserEmail(auth.currentUser.uid).toString();

    var ParticipantsIn = await firestore.collection('ParticipantsInChallenge').where("ChalangeID",isEqualTo: Challange1_ID.toString())
        .where("Email",isEqualTo:userEmail).get();
    print(ParticipantsIn.docs.length);

    if (ParticipantsIn == ParticipantsIn.docs.isEmpty ){
      ParticipantsInChallenge.add({
        'Name': await getUserName(auth.currentUser.uid),
        'Phone': await getUserPhone(auth.currentUser.uid),
        "Email": await getUserEmail(auth.currentUser.uid),
        "ChalangeID": await Challange1_ID,
      });
      Navigator.of(context).pop();
    }
    else
    {
      _showMassege();
    }
  }

  String GetChallangeID(String ChallangeIDStream) {
    return ChallangeIDStream;
  }


  void _showDialog(String Challange1_ID) {

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: new Text("Do you want to participate in the challenge? "),
          content: new Text("If you want click Yes pleas"),
          actions: <Widget>[
            new FlatButton(
              child: new Text("Yes"),
              onPressed: () {
                ParticipateAtChallanges(Challange1_ID);
              },
            ),
            new FlatButton(
              child: new Text("Close"),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _showMassege() {

    showDialog(
      context: context,
      builder: (BuildContext context) {
        // return object of type Dialog
        return AlertDialog(
          title: new Text("You have been participated in this challange ! "),

        );
      },
    );
  }


  @override
  Widget build(BuildContext context) {
    nested() {
      return NestedScrollView(
        headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
          return <Widget>[
            SliverAppBar(
              //expandedHeight: 200.0,
              // floating: false,
              // pinned: true,

              centerTitle: true,
              title: Text(
                'Challanges Page',
                style: TextStyle(
                  color: Colors.pink[900],
                  //fontSize: 30.0,
                  //fontWeight: FontWeight.bold,
                ),
              ),
              backgroundColor: Colors.orange[200],

              actions: [
                IconButton(
                    icon: Icon(
                      Icons.notifications,
                      color: Colors.pink[900],
                    ),
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (BuildContext context) {
                            return notificationPart();
                          }));
                    })
              ],
            ),
          ];
        },
        body: ListView(scrollDirection: Axis.vertical,
            children: [
              Container(
                height: 180.0,
                width: double.infinity,
                child: Carousel(
                  boxFit: BoxFit.fill,
                  autoplay: true,
                  autoplayDuration: Duration(seconds: 5),
                  animationCurve: Curves.fastOutSlowIn,
                  animationDuration: Duration(milliseconds: 1000),
                  dotSize: 8.0,
                  dotSpacing: 10,
                  dotColor: Colors.black,
                  dotIncreasedColor: Color(0xFFFF335C),
                  dotBgColor: Colors.orange[200].withOpacity(0.5),
                  dotPosition: DotPosition.bottomCenter,
                  dotVerticalPadding: 00.0,
                  borderRadius: true,
                  radius: Radius.circular(40),
                  overlayShadow: true,
                  overlayShadowColors: Colors.brown,
                  overlayShadowSize: 0.2,
                  showIndicator: true,
                  indicatorBgPadding: 10.0,
                  images: [
                    AssetImage('images/markiting.jpg'),
                    AssetImage('images/carasol1.jpg'),
                    AssetImage('images/carasol2.jpg'),
                    AssetImage('images/carasol3.jpg'),
                    AssetImage('images/carasol4.jpg'),
                    AssetImage('images/carasol5.jpg'),
                    AssetImage('images/carasol6.jpg'),
                  ],
                ),
              ),
              Container(
                color: Colors.orange[50],
                padding: EdgeInsets.all(8),
                child: Text(
                  "Challenges",
                  style: TextStyle(
                    fontSize: 30,
                    color: Colors.pink[900],
                  ),
                ),
              ),
              Container(
                //   elevation: 8.0,
                // margin:
                // new EdgeInsets.symmetric(horizontal: 0.0, vertical: 20.0),
                child: Container(
                  decoration:
                  BoxDecoration(
                      color: Colors.orange[50]
                  ),
                  child:  myLocation != null
                      ? StreamBuilder(
                      stream: getDocumentNearB(myLocation),
                      builder: (context, AsyncSnapshot<List> snapshot) {
                        if (snapshot.hasData) {
                          return Container(

                            //   height: 170,
                              height: MediaQuery.of(context).size.height,
                              width: MediaQuery.of(context).size.width,
                              child: ListView.builder(
                                itemCount: snapshot.data.length,
                                itemBuilder: (context, index) {
                                  var doc = snapshot.data[index].data;

                                  return Card(
                                      color: Colors.grey[200],
                                      margin: EdgeInsets.all(15),
                                      child: ListTile(
                                        title: Text(
                                            "\nChalange Title:  " +
                                                snapshot
                                                    .data
                                                [index]
                                                ['ChalangeName']
                                                    .toString(),
                                            style: TextStyle(
                                              fontSize: 30.0,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.orange[300],
                                            )),

                                        subtitle: Text(
                                            "\n \nSponcer BY:  " +
                                                snapshot.data
                                                [index]['StoreName']
                                                    .toString() +
                                                "\n \nDescription:  " +
                                                snapshot
                                                    .data
                                                [index][
                                                'ChallangeDescription']
                                                    .toString() +
                                                "\n \nDate:   " +
                                                snapshot
                                                    .data
                                                [index]
                                                ['ChalangeDate']
                                                    .toString(),
                                            style: TextStyle(
                                                fontSize: 20.0,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.pink[900])),

                                        trailing: IconButton(
                                          icon: Icon(Icons.group_add),
                                          tooltip: 'participate',
                                          color: Colors.pink[900],
                                          iconSize: 48,
                                          //alignment: Alignment.bottomLeft,
                                          onPressed: () {
                                            String Chall_ID = GetChallangeID(
                                                snapshot.data[index].id
                                                    .toString());

                                            _showDialog(Chall_ID);

                                          },
                                        ),

                                      ),

                                  );

                                  //);
                                },
                              ));
                        } else
                          return new Container(
                            child: Center(
                                child: new CircularProgressIndicator()),
                          );
                      }) : Center(
                    child: Text(
                      'your neighborhood is not covered by our coupons yet',
                      style: TextStyle(
                        fontSize: 20,
                        color: Colors.grey,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              ),
            ],
          ),

      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      drawer: OurDrawer(),
      body: nested(),
    );
  }
}