import 'dart:ui';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:exsb_app_gp/Advertiser%20pages/NotificationsAdv.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../drawerADV.dart';
import 'AllPackages.dart';

class DescriptionPackage extends StatefulWidget {
  final packegename;
  final description;

  DescriptionPackage({this.packegename, this.description});

  @override
  _DescriptionPackage createState() => _DescriptionPackage();
}

class _DescriptionPackage extends State<DescriptionPackage> {
  final firestore = FirebaseFirestore.instance; //
  FirebaseAuth auth = FirebaseAuth.instance; //recommend declaring a reference outside the methods

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            widget.packegename,
            style: TextStyle(color: Colors.pink[900]),
          ),
          centerTitle: true,
          backgroundColor: Colors.orange[200],
          actions: [
            IconButton(
                icon: Icon(
                  Icons.notifications,
                  color: Colors.pink[900],
                ),
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (BuildContext context) {
                    return notificationAdv();
                  }));
                })
          ],
        ),
        drawer: drawerADV(),
        body: Container(
          color: Colors.orange[50],
          child:ListView(
            children: [
              SizedBox(
                height: 20,
              ),
              Text(
                '             Package Information ',
                style: TextStyle(fontSize: 25, color: Colors.pink[900]),
              ),
              SizedBox(
                height: 30,
              ),
              new Image.asset('images/package.png',
                  fit: BoxFit.fill, width: 100.0, height: 100.0),
              Card(
                elevation: 20,
                margin: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
                color: Colors.white,
                child: ListTile(
                  title: Text(
                    widget.description,
                    style: TextStyle(fontSize: 17),
                  ),
                  contentPadding:
                  EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                  leading: Icon(
                    Icons.star,
                    size: 30,
                    color: Colors.pink[900],
                  ),
                  onTap: () {},
                ),
              ),
              const SizedBox(height: 20.0),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  vertical: 8.0,
                  horizontal: 10.0,
                ),
                child: RaisedButton(
                  elevation: 0,
                  padding: const EdgeInsets.all(1.0),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0)),
                  child: Text("Back"),
                  color: Colors.pink[900],
                  textColor: Colors.white,
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (BuildContext context) {
                          return package();
                        }));
                  },
                ),
              ),
            ],
          ) ,
        )

      ),
    );
  }
}
