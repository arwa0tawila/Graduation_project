import 'package:carousel_pro/carousel_pro.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:exsb_app_gp/Advertiser%20pages/ChallangePageForAdv.dart';
import 'package:exsb_app_gp/Advertiser%20pages/NotificationsAdv.dart';
import 'package:exsb_app_gp/drawerADV.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

class Payment300 extends StatefulWidget {
  @override
  _Payment300 createState() => _Payment300();
}
final String uid = auth.currentUser.uid;
FirebaseAuth auth = FirebaseAuth
    .instance; //recommend declaring a reference outside the methods
class _Payment300 extends State<Payment300> {
  final firestore = FirebaseFirestore.instance; //
  int newbalance;
  Future<int> getUserBalance() async {
    final firestore = FirebaseFirestore.instance;
    final CollectionReference users = firestore.collection('Advertisers');
    final String uid = auth.currentUser.uid;
    int b;
    final result = await users.doc(uid).get();

    if(result.data() != null){
      b= result.data()['Balance'];
    }

    newbalance = b;

  }
  @override
  void initState() {
    getUserBalance();
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.orange[200],
          elevation: 0,
          iconTheme: IconThemeData(
            color: Colors.black,
          ),
          title: Text(
            'payment methods',
            style: TextStyle(color: Colors.pink[900]),
          ),
          centerTitle: true,
          actions: [
            IconButton(
                icon: Icon(
                  Icons.notifications,
                  color: Colors.pink[900],
                ),
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (BuildContext context) {
                        return notificationAdv();
                      }));
                })
          ],
        ),
        drawer: drawerADV(),
        body:Container(
          color: Colors.orange[50],
          child:SingleChildScrollView(
            child: Column(children: [
              Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("images/payment.jpg"), fit: BoxFit.cover),
                ),
              ),
              Text(
                "How Do You Want To Pay",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18.0,
                    color: Colors.pink[900]),
              ),

              Container(
                height: 150.0,
                width: double.infinity, // عشان يبقا الصورة بعرض الصفحة كلها
                child: Carousel(
                  boxFit: BoxFit.cover,
                  // عشان يخلي كل الصور اللي بضيفها اد الشاشة
                  autoplay: true,
                  // ان الصور تتحرك بشكل تلقائي
                  autoplayDuration: Duration(seconds: 2),
                  // كل اد ايه تتحرك الصورة
                  animationCurve: Curves.fastOutSlowIn,
                  animationDuration: Duration(milliseconds: 1000),
                  dotSize: 8.0,
                  // خاصة بالدواير الصغيرة لما يحرك الصورة وكده والقيمة الافتراضية هيا 8
                  dotSpacing: 10,
                  // المسافة ما بين كل نقطة والتانية
                  dotColor: Colors.black,
                  // لون النقط
                  dotIncreasedColor: Color(0xFFFF335C),
                  //dotBgColor: Colors.transparent,// بتكون كده لو مش عاوزة النقط وراها خلفية ولا حاجة
                  dotBgColor: Colors.orangeAccent.withOpacity(0.5),
                  dotPosition: DotPosition.bottomCenter,
                  // هنا لها خلفية لونها اوارنج وفيها خاصية الشفافية
                  dotVerticalPadding: 00.0,
                  // المسافة بين الشريط واسفل الصورة ، خليته 0 لان مش عاوزة مسافة
                  borderRadius: true,
                  //بتخلي  الشريط اللى ورا النقط
                  radius: Radius.circular(40),
                  // بتزود الدوران اللى ف الشريط
                  overlayShadow: true,
                  // بتزود التظليل بتاع الشريط
                  overlayShadowColors: Colors.brown,
                  // لون الشادو اللي ورا الخط
                  overlayShadowSize: 0.2,
                  // مقاس الشادو الافتراضي 0.5 يعني المربع كله ولكن انا هنا حطيته كده لاني عاوزاه من تحت بس
                  showIndicator: true,
                  // دي قيمتها الافتراضية ترو بحيث انه دايما يظهر النقط او الشريط لو اخترنا نحطه
                  indicatorBgPadding: 10.0,
                  // عرض الشريط اللي ورا النقط

                  images: [
                    // الكارسول بيقبل صور من نوع ليست فيها كل الصور اللى جابة تنضاف للموقع
                    Image.asset(
                      "images/buy.jpg",
                      fit: BoxFit.fill,
                    ),
                    // دي الصور اللى عاوزينها تظهر ف الصفحة ،لازم الاول نحطها ف ملف assets وبعدين نضيفها ف pubspec.yaml
                    //Image.asset('assets/iconfinder_5_5027876.png',fit: BoxFit.cover,), // الصورة ممكن نضيفها بطريقتين زي ما انا عاملة كده
                    Image.asset("images/pay.jpg", fit: BoxFit.fill),
                    Image.asset(
                      "images/payment.jpg",
                      fit: BoxFit.fill,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20.0),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  vertical: 10.0,
                  horizontal: 32.0,
                ),
                child: RaisedButton(
                  elevation: 0,
                  padding: const EdgeInsets.all(9.0),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0)),
                  child: ListTile(
                    leading: Icon(
                      Icons.payment,
                      size: 30,
                      color: Colors.white,
                    ),
                    title: Text(
                      "PayPal",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  color: Colors.pink[900],
                  textColor: Colors.white,
                  onPressed: () {},
                ),
              ),
              //const SizedBox(height: 20.0),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  vertical: 10.0,
                  horizontal: 32.0,
                ),
                child: RaisedButton(
                  elevation: 0,
                  padding: const EdgeInsets.all(9.0),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0)),
                  child: ListTile(
                    leading: Icon(
                      Icons.payment,
                      size: 30,
                      color: Colors.white,
                    ),
                    title: Text(
                      "ApplePay",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  color: Colors.pink[900],
                  textColor: Colors.white,
                  onPressed: () {},
                ),
              ),
              //const SizedBox(height: 20.0),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  vertical: 10.0,
                  horizontal: 32.0,
                ),
                child: RaisedButton(
                  elevation: 0,
                  padding: const EdgeInsets.all(9.0),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0)),
                  child: ListTile(
                    leading: Icon(
                      Icons.payment,
                      size: 30,
                      color: Colors.white,
                    ),
                    title: Text(
                      "Visa Card",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  color: Colors.pink[900],
                  textColor: Colors.white,
                  onPressed: () {},
                ),
              ),

              //const SizedBox(height: 20.0),
             Row(
               mainAxisAlignment: MainAxisAlignment.spaceAround,
               children: [
                 RaisedButton(
                   elevation: 0,
                   padding: EdgeInsets.only(right: 80,left: 80),
                   shape: RoundedRectangleBorder(
                       borderRadius: BorderRadius.circular(50)),
                   child: Text("Continue" , style: TextStyle(fontSize: 25),),
                   color: Colors.orange[200],
                   textColor: Colors.pink[900],
                   onPressed: () {

                     if (newbalance >= 300){
                       updateUserBalance();
                       displayToastMassage(
                           '300 SAR has been deducted from your balance', context);
                       Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
                         return ChallangePageForAdv();
                       }));
                     }else {
                       displayToastMassage(
                           'You do not have enough money', context);
                     }


                   },
                 ),
               ],
             )


            ]),
          ) ,
        )

      ),
    );
  }


  updateUserBalance() async {
    final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
    User firebaseUser = _firebaseAuth.currentUser;

    if (_firebaseAuth.currentUser != null) {
      FirebaseFirestore.instance.collection("Advertisers").doc(
          firebaseUser.uid).update({
        'Balance' : newbalance - 300,

      });

    }
  }
  displayToastMassage(String massage, BuildContext context) {
    Fluttertoast.showToast(msg: massage,);
  }
}