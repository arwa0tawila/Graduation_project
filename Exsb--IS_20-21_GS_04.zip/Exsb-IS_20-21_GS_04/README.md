Project Title
Exsb for attractive advertising.
Getting Started
This project is a starting point for a Flutter application.
A few resources to get you started if this is your first Flutter project:
- [Lab: Write your first Flutter app]
(https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples]
(https://flutter.dev/docs/cookbook)For help getting started with Flutter, 
view our[online documentation](https://flutter.dev/docs), 
which offers tutorials,samples, guidance on mobile development, and a full API reference.
Prerequisites
Basic Knowledge about Android studio, flutter and dart language.
Download all related library.
Network.
Machine.
Give examples
First download Android studio in your machine
create Flutter Project in Android Studio https://www.youtube.com/watch?v=oy9cgYxU-X4
Then get the link from the GitHub to clone the project
Then run the application
Installing
Android studio https://developer.android.com/studio
on windows 10: https://www.youtube.com/watch?v=0zx_eFyHRU0
Running the tests
Unit testing.
Deployment
The app is not currently published nor available on the App Store
Built With
Android studio 4.1
Flutter 1.26.0
Dart language 2.12.0
Versioning
Android 11.0 R
Authors
Arwa Tawila, Amnah fuad, Fatima Alshahat, Halima Alhusini, Raghad Alhashmi
License
NDK (OPSOLECE).
Apache License.
SDK.
Acknowledgments
We are grateful and thankful for Allah then the team members themselves for supporting each other’s, our families for their trust and our supervisor, Dr. DeafAllah Al-Sadie.