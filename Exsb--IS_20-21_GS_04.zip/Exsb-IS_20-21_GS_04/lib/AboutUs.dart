import 'package:flutter/material.dart';

import 'drawerPart.dart';

class AboutUs extends StatefulWidget {
  @override
  _AboutUsState createState() => _AboutUsState();
}

class _AboutUsState extends State<AboutUs> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(
          appBar: AppBar(
            title: Text('About Us',style: TextStyle(color: Colors.pink[900]),),
            centerTitle: true,
            backgroundColor: Colors.orange[200],


            actions: [IconButton(icon: Icon(Icons.notifications, color: Colors.pink[900],), onPressed: (){})],

          ),

          drawer: OurDrawer(),

          body: Container(
            color: Colors.orange[50],
            child: ListView(

                children:[
                  SizedBox(height: 30,),
                  Image.asset("images/exsbLogo.png",
                    width: 100,height: 200, fit: BoxFit.fill, ),
                  Card(
                    color: Colors.orange[50],

                    // elevation: 20,
                    margin: EdgeInsets.symmetric(horizontal: 3, vertical: 2),

                    child: ListTile(

                      title: Text('Part of the partial fulfillment of Bachelor of Information Systems degree \n\nCollege of Computer and Information Systems,'
                          ' Al-Zaher Campus '
                          '\n \n Supervised By Dr. Deafallah Alsadie team work: \n'
                          'Arwa tawila – s437036308@st.uqu.edu.sa \n'
                          'Amnah fuad – s437034414@st.uqu.edu.sa \n'
                          'Fatima Alshahat – s437036317@st.uqu.edu.sa \n'
                          'Halima Alhusini – s437035781@st.uqu.edu.sa \n'
                          'Raghad Alhashmi – s437005291@st.uqu.edu.sa \n ',style: TextStyle(fontSize: 16,color: Colors.pink[900]),textAlign: TextAlign.center,),
                      contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 60),

                    ),



                  ),

                ]),
          )

        ));

  }
}