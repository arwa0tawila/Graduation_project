import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'Advertiser pages/AllPackages.dart';
import 'Advertiser pages/CouponsPageForAdvertiser.dart';
import 'ChooseUserToCreatAccount.dart';
import 'Participant pages/SpesifyLocationPage.dart';




class sighninscreen extends StatefulWidget {
  @override
  _sighninscreenState createState() => _sighninscreenState();
}

class _sighninscreenState extends State<sighninscreen> {
  TextEditingController _emailAddressField = TextEditingController();
  TextEditingController _passwordField = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('Login screen', style: TextStyle(color: Colors.pink[800], fontSize: 30),),
          centerTitle: true,
          backgroundColor: Colors.orange[200],

        ),

        body:  Container(
          color: Colors.orange[50],
          child:ListView(
            key: _formKey,
            padding: EdgeInsets.all(10),
            children: [
              Image.asset("images/exsbLogo.png",
                width: 150,height: 250, fit: BoxFit.fill, ),


              SizedBox(height: 30,width: 20,),
              Form(child: Column(children: [
                TextFormField(
                  controller: _emailAddressField,
                  keyboardType: TextInputType.emailAddress,
                  obscureText: false,
                  decoration: InputDecoration(
                      hintText: "something@email.com",
                      labelText: "Email",
                      labelStyle: TextStyle(color: Colors.pink[900]),
                      fillColor: Colors.grey[200],
                      filled: true,
                      prefixIcon: Icon(Icons.person, color: Colors.pink[900],),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),

                      )
                  ),
                ),
                SizedBox(height: 10,width: 20,),
                TextFormField(
                  controller: _passwordField ,
                  obscureText: true,
                  obscuringCharacter: "*",
                  decoration: InputDecoration(
                      labelText: "Password ",
                      labelStyle: TextStyle(color: Colors.pink[900]),
                      fillColor: Colors.grey[200],
                      filled: true,
                      prefixIcon: Icon(Icons.vpn_key_rounded, color: Colors.pink[900],),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),

                      )
                  ),
                ),
              ],)),
              //SizedBox(height: 30,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  RaisedButton(
                    padding: EdgeInsets.only(right: 80,left: 80),

// padding: EdgeInsets.only(right: 80,left: 80),
                    color: Colors.pink[900],
                    shape:   StadiumBorder(
                      side: BorderSide(
                        color: Colors.blueGrey,
                        width: 1.0,
                      ),
                    ),
//elevation: ,
                    onPressed:(){
                      _emailAddressField.text.isNotEmpty
                          && _passwordField.text.isNotEmpty
                          ? signinUser()
                          : displayToastMassage("Enter your Email And Password", context);
                    },
                    child: Text('Log In', style: TextStyle(
                        fontSize: 25,
                        color: Colors.white
                    ),),
                  ),
                ],
              ),

              Text("Dont have account ? click here to creat account"),
              //SizedBox(height: 30,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  RaisedButton(
                    padding: EdgeInsets.only(right: 30,left: 35),

                    color: Colors.pink[900],
                    shape:   StadiumBorder(
                      side: BorderSide(
                        color: Colors.black54,
                        width: 1.0,
                      ),
                    ),
//elevation: ,
                    onPressed:(){
                      Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
                        return chooseusertocreataccount();
                      }));
                    },
                    child: Text('Create Account', style: TextStyle(
                        fontSize: 25,
                        color: Colors.white
                    ),),
                  ),
                ],
              ),


              Text("Forget Password ? click here to Reset Password"),
              //SizedBox(height: 30,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  RaisedButton(
                    color: Colors.pink[900],
                    shape:   RoundedRectangleBorder(
                      side: BorderSide(

                        color: Colors.black54,
                        width: 1.0,
                      ),
                      borderRadius: BorderRadius.circular(50.0),
                    ),
                    //elevation: ,
                    onPressed: (){
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => ResetScreen()),
                      );


                    },
                    child: Text('Forgot Password?', style: TextStyle(
                        fontSize: 25,
                        color: Colors.white
                    ),),
                  ),
                ],
              )

            ],
          ),
        )

      ),
    );
  }

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  Future<void> signinUser() async {
    User firebaseUser;
    await _firebaseAuth.signInWithEmailAndPassword(
      email: _emailAddressField.text.trim(),
      password: _passwordField.text.trim(),
    ).then((firebaseAuth){
      firebaseUser = firebaseAuth.user;});
    if (firebaseUser.uid != null   ){
      FirebaseFirestore.instance.collection("Advertisers").doc(firebaseUser.uid).get().then((DocumentSnapshot snap ) {
        if (snap.data() != null) {
          print(snap.data());
          Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
            builder: (BuildContext context) => package(),
          ), (route) => true);
          displayToastMassage("Successful entry", context);}
        else   {
          FirebaseFirestore.instance.collection("Participants").doc(firebaseUser.uid).get().then((DocumentSnapshot snap  ) {
            if (snap.data() != null) {
              print(snap.data());
              Navigator.pushAndRemoveUntil(context, MaterialPageRoute(
                builder: (BuildContext context) => SpecifyLocationScreen(),
              ), (route) => true);
              displayToastMassage(
                  "Successful entry", context);}
            else{
              _firebaseAuth.signOut();
              displayToastMassage(
                  "not exist account ", context);
            }
          }
          );
        }
      });
    }

    else {
      displayToastMassage("ِError Occured, can not be Sign-in ", context) ;//error accared display error msg
    }
  }
}

class ResetScreen extends StatefulWidget {
  @override
  _ResetScreenState createState() => _ResetScreenState();
}

class _ResetScreenState extends State<ResetScreen> {
  String _email;
  final auth = FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Reset Password' , style: TextStyle(color: Colors.pink[800], fontSize: 30),),
        centerTitle: true,
        backgroundColor: Colors.orange[200],
      ),
      body: Container(
        color: Colors.orange[50],
        child: ListView(
          children: [
            Image.asset("images/exsbLogo.png",
              width: 150,height: 250, fit: BoxFit.fill, ),

            Column(

              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextField(
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                        hintText: 'Email',
                        labelStyle: TextStyle(color: Colors.pink[900]),
                        fillColor: Colors.grey[200],
                        filled: true,
                        prefixIcon: Icon(Icons.person, color: Colors.pink[900],),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(20),

                        )
                    ),
                    onChanged: (value) {
                      setState(() {
                        _email = value.trim();
                      });
                    },
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    RaisedButton(
                      color: Colors.pink[900],
                      shape:   StadiumBorder(
                        side: BorderSide(
                          color: Colors.blueGrey,
                          width: 1.0,
                        ),
                      ),

                      child: Text('Send Request' , style: TextStyle(
                          fontSize: 25,
                          color: Colors.white
                      ),),
                      onPressed: () {
                        auth.sendPasswordResetEmail(email: _email);
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                ),
              ],),
          ],
        )

      )

    );
  }
}
