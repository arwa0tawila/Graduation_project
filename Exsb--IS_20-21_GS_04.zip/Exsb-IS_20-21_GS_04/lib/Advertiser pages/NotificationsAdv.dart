import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:exsb_app_gp/Advertiser%20pages/AllCompitionsAdv.dart';
import 'package:exsb_app_gp/drawerADV.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';


class notificationAdv extends StatefulWidget {
  @override
  _notificationAdv createState() => _notificationAdv();
}

class _notificationAdv extends State<notificationAdv> {
  final firestore = FirebaseFirestore.instance;   //
  FirebaseAuth auth = FirebaseAuth.instance;     //recommend declaring a reference outside the methods

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('Notifications',style: TextStyle(color: Colors.pink[900]),),
          centerTitle: true,
          backgroundColor: Colors.orange[200],

          actions: [IconButton(icon: Icon(Icons.notifications, color: Colors.pink[900],), onPressed: (){})],
        ),
        drawer: drawerADV(),

        body: ListView(

          children: [
            SizedBox(height: 20,),


            Text('   Notification:', style: TextStyle(fontSize: 20, color: Colors.pink[900]),),
            Card(
              elevation: 20,
              margin: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
              color: Colors.pink[900],

              child: ListTile(
                title: Text('You can customize your OWN events in the Dimond package ',style: TextStyle(fontSize: 20,color: Colors.white),),
                contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                leading: CircleAvatar(backgroundImage: AssetImage('images/exsbLogo.png'),),


                onTap: (){
                },

              ),

            ),

            Card(
              elevation: 20,
              margin: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
              color: Colors.pink[900],
              child: ListTile(
                title: Text(' Exclusive events in the Gold package ', style: TextStyle(fontSize: 20,color: Colors.white),),
                contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                leading: CircleAvatar(backgroundImage: AssetImage('images/exsbLogo.png'),),
                onTap: (){

                },
              ),
            ),
            Card(
              elevation: 20,
              margin: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
              color: Colors.pink[900],
              child: ListTile(
                title: Text('new question in the Silver pakage ',style: TextStyle(fontSize: 20,color: Colors.white),),
                contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                leading: CircleAvatar(backgroundImage: AssetImage('images/exsbLogo.png'),),
                onTap: (){

                },

              ),
            ),
            Card(
              elevation: 20,
              margin: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
              color: Colors.pink[900],

              child: ListTile(
                title: Text('new events in the Dimond package ',style: TextStyle(fontSize: 20,color: Colors.white),),
                contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                leading: CircleAvatar(backgroundImage: AssetImage('images/exsbLogo.png'),),


                onTap: (){
                },

              ),

            ),
            Card(
              elevation: 20,
              margin: EdgeInsets.symmetric(horizontal: 30, vertical: 10),
              color: Colors.pink[900],

              child: ListTile(
                title: Text('new events in the Gold package ',style: TextStyle(fontSize: 20,color: Colors.white),),
                contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 10),
                leading: CircleAvatar(backgroundImage: AssetImage('images/exsbLogo.png'),),


                onTap: (){
                },

              ),

            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(
                vertical: 8.0,
                horizontal: 10.0,
              ),
              child: RaisedButton(
                elevation: 0,
                padding: const EdgeInsets.all(3.0),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0)),
                child: Text("back"),
                color: Colors.orange[200],
                textColor: Colors.pink[900],
                onPressed: () {

                  Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
                    return AllCompitionsAdv();
                  }));

                },
              ),
            ),

          ],

        ),
      ),
    );
  }
}