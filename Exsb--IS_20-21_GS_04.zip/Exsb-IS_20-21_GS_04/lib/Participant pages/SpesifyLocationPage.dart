
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:geoflutterfire/geoflutterfire.dart';
import 'package:location/location.dart';
import '../main.dart';
import 'AllCompitionsPart.dart';

class SpecifyLocationScreen extends StatefulWidget {
  @override
  _SpecifyLocationScreenState createState() => _SpecifyLocationScreenState();

}

class _SpecifyLocationScreenState extends State<SpecifyLocationScreen> {
  final firestore = FirebaseFirestore.instance;   //
  FirebaseAuth auth = FirebaseAuth.instance;
  String dropstate='Alawali';
  bool _serviceEnabled;
  PermissionStatus _permissionGranted;
  LocationData _location;
  final databaseReference = FirebaseDatabase.instance.reference();
  CollectionReference location_ref = FirebaseFirestore.instance.collection('Participants');

  @override
  void initState() {
    updateToken();
    super.initState();
  }

  Future updateToken() async {
    location_ref.doc(auth.currentUser.uid).set({'token': await messaging.getToken()},SetOptions(merge: true));
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Directionality(textDirection: TextDirection.ltr, child: Scaffold(
          appBar: AppBar(
            title: Text('Specify Location Screen',style: TextStyle(color: Colors.pink[900]),),
            centerTitle: true,
            backgroundColor: Colors.orange[200],

          ),




          body:Container(
            color: Colors.orange[50],
            child:ListView(
              padding: EdgeInsets.all(20),
              children: [

                Image.asset("images/location-restorant.gif", height: 200, width: 200, fit: BoxFit.fill,),

                SizedBox(height: 30,),


                Text(' Specify Your Location automatically : ', style: TextStyle(fontSize: 20, color: Colors.pink[900], ),),
                SizedBox(height: 30,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,

                  children: [
                    RaisedButton(
                      // padding: EdgeInsets.only(right: 80,left: 80),
                      color: Colors.pink[900],
                      shape:   StadiumBorder(
                        side: BorderSide(
                          color: Colors.black54,
                          width: 1.0,
                        ),
                      ),
                      //elevation: ,
                      onPressed:(){
                        checkLocationInDevise();
                      },
                      child: Text('Save', style: TextStyle(
                          fontSize: 25,
                          color: Colors.white
                        //decoration: new InputDecoration()
                      ),),
                    )
                  ],
                )


              ],
            ) ,
          )







        ),)
    );
  }





  Future<void> checkLocationInDevise() async {// عشاان نعرف هل خدمة GPS مفعلة في البرنامج او لا

    Location location = new Location();
    _serviceEnabled = await location.serviceEnabled();

    if (_serviceEnabled)
    {

      // print('gps enabled');
      _permissionGranted = await location.hasPermission();
      if(_permissionGranted == PermissionStatus.granted)
      {
        print("------------------------------0000000-----------");
        storeUserLocation();
        _someFunction();



        print("------------------------------11111------------");
        //    });

      }else
      {
        _permissionGranted = await location.requestPermission();// requst
        if(_permissionGranted == PermissionStatus.granted )
        {
          storeUserLocation();
          _someFunction();

        }else {
          SystemNavigator.pop();
        }

      }

    }else {
      _serviceEnabled = await location.requestService();
      if (_serviceEnabled){
        _permissionGranted = await location.hasPermission();
        if(_permissionGranted == PermissionStatus.granted)
        {
          _location = await location.getLocation();

          storeUserLocation();
        }else
        {
          SystemNavigator.pop();
        }
      }

    }
  }

  storeUserLocation(){



    Location location = new Location();
    location.onLocationChanged.listen((LocationData currentLocation) {
      location_ref.doc(auth.currentUser.uid).update({
        'location': GeoPoint(currentLocation.latitude, currentLocation.longitude)
      }).asStream();
    });
    Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
      return AllCompitionsPart();
    }));

  }

  Geoflutterfire geo = Geoflutterfire();
  Future<dynamic> _someFunction() async {

    DocumentReference documentReference = location_ref.doc(auth.currentUser.uid);
    GeoFirePoint point;
    await documentReference.get().then((DocumentSnapshot snap) {
      var fireBase = snap.data()['location'];
      point = geo.point(
          latitude: double.parse('${fireBase.latitude}'),
          longitude: double.parse('${fireBase.longitude}'));
      print(point.data);
    });
    location_ref.doc(auth.currentUser.uid).update({
      'position': point.data
    }).asStream();
  }

}