
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:exsb_app_gp/drawerPart.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'ChallengePart.dart';
import 'Coupons_Partic..dart';
import 'NotifcationsPart.dart';
import 'QuistionPart.dart';
import 'TeamChallengePart.dart';

class AllCompitionsPart extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final title = "Home";
    final firestore = FirebaseFirestore.instance;   //
    FirebaseAuth auth = FirebaseAuth.instance;

    return Scaffold(
        appBar: AppBar(
          elevation: 0.1,
          title: Text(
            title,
            style: TextStyle(
              color: Colors.pink[900],
              fontSize: 30.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.orange[200],
          centerTitle: true,

          actions: [IconButton(icon: Icon(Icons.notifications, color: Colors.pink[900],), onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
              return notificationPart();
            }));
          })],
        ),

        drawer: OurDrawer(),

        body: new Container(
          color: Colors.orange[50],
          child: ListView(
              children: <Widget>[
                InkWell(

                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (context) => CouponsPageForParticipants())),
                  child: Card(
                      color: Colors.white,
                      child: Column(
                        children: <Widget>[
                          new Container(
                              padding: const EdgeInsets.all(8.0),
                              child: Image.asset('images/f.jpg')),
                          new Container(
                            padding: const EdgeInsets.all(10.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  'Coupons',
                                  style: TextStyle(
                                    color: Colors.pink[900],
                                    fontSize: 30,
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                        crossAxisAlignment: CrossAxisAlignment.start,
                      )),
                ),
                InkWell(
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (context) => QuistionPart())),
                  child: Card(
                      color: Colors.white,
                      child: Column(
                        children: <Widget>[
                          new Container(
                              padding: const EdgeInsets.all(8.0),
                              child: Image.asset('images/Question2.jpg')),
                          new Container(
                            padding: const EdgeInsets.all(10.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  'Questions',
                                  style: TextStyle(
                                    color: Colors.pink[900],
                                    fontSize: 30,
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                        crossAxisAlignment: CrossAxisAlignment.start,
                      )),
                ),
                InkWell(
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (context) => listchallange())),
                  child: Card(
                      color: Colors.white,
                      child: Column(
                        children: <Widget>[
                          new Container(
                              padding: const EdgeInsets.all(8.0),
                              child: Image.asset('images/dd.jpg')),
                          new Container(
                            padding: const EdgeInsets.all(10.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  'Challanges',
                                  style: TextStyle(
                                    color: Colors.pink[900],
                                    fontSize: 30,
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                        crossAxisAlignment: CrossAxisAlignment.start,
                      )),
                ),
                InkWell(
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (context) => ListTeamChallange())),
                  child: Card(
                      color: Colors.white,
                      child: Column(
                        children: <Widget>[
                          new Container(
                              padding: const EdgeInsets.all(8.0),
                              child: Image.asset('images/kk.jpg')),
                          new Container(
                            padding: const EdgeInsets.all(10.0),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                Text(
                                  'team Challange',
                                  style: TextStyle(
                                    color: Colors.pink[900],
                                    fontSize: 30,
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                        crossAxisAlignment: CrossAxisAlignment.start,
                      )),
                ),
              ]),
        )
        );
  }
}

class menu {
  final String title;
  final String imglink;
  const menu({this.title, this.imglink});
}
