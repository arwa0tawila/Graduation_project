import 'package:carousel_pro/carousel_pro.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geoflutterfire/geoflutterfire.dart';
import '../drawerPart.dart';
import 'NotifcationsPart.dart';

class QuistionPart extends StatefulWidget {
  QuistionPart({this.app});

  final FirebaseApp app;

  State<StatefulWidget> createState() {
    return _QuistionPartState();
  }
}

class _QuistionPartState extends State<QuistionPart> {

  final firestore = FirebaseFirestore.instance; //
  FirebaseAuth auth = FirebaseAuth
      .instance; //recommend declaring a reference outside the methods

  Future<List> getAllQusetions() async {
    var users = await firestore.collection('Questions').get();
    return users.docs;
  }

  var _firstPress = true;

  Geoflutterfire geo = Geoflutterfire();
  GeoFirePoint myLocation;

  Future<GeoFirePoint> _getUserLocation() async {
    final CollectionReference par = firestore.collection("Participants");
    DocumentReference documentReference = par.doc(auth.currentUser.uid);
    GeoFirePoint point0;
    await documentReference.get().then((DocumentSnapshot snap) {
      if (snap.exists) {
        var fireBase = snap.data()['location'];
        point0 = geo.point(
            latitude: double.parse('${fireBase.latitude}'),
            longitude: double.parse('${fireBase.longitude}'));
      }
    });
    setState(() {
      myLocation = point0;
    });
    // return point0;
  }

  var useremail;

  Future<String> getUserEmail(String uid) async {
    // final CollectionReference users = firestore.collection('Participants');
    DocumentReference documentReference =
    firestore.collection('Participants').doc(uid);
    String Uemail;
    await documentReference.get().then((snapshot) {
      Uemail = snapshot.data()['email'];
    });
    setState(() {
      useremail = Uemail.toString();
    });
  }

  Stream<List<DocumentSnapshot>> getDocumentNearB(GeoFirePoint userLocation) {
    double radius = 50;
    String field = 'position';
    var docRef = firestore.collection("Questions");
    Stream<List<DocumentSnapshot>> query = geo
        .collection(collectionRef: docRef)
        .within(
        center: userLocation /*await _someFunction1(auth.currentUser.uid)*/,
    radius: radius,
    field: field,
    strictMode: true);

    return query;
  }

  @override
  void initState() {
    getUserEmail(auth.currentUser.uid);
    _getUserLocation();
    print('My location --> ${myLocation?.data}');
    super.initState();
  }

  String GetChallangeID(String ChallangeIDStream) {
    return ChallangeIDStream;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            "Questions Page",
            style: TextStyle(color: Colors.pink[900]),
          ),
          backgroundColor: Colors.orange[200],
          centerTitle: true,
          actions: [
            IconButton(
                icon: Icon(
                  Icons.notifications,
                  color: Colors.pink[900],
                ),
                onPressed: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (BuildContext context) {
                        return notificationPart();
                      }));
                })
          ],
        ),
        drawer: OurDrawer(),
        body: ListView(scrollDirection: Axis.vertical, children: [
          Container(
            height: 180.0,
            width: double.infinity,
            child: Carousel(
              boxFit: BoxFit.fill,
              autoplay: true,
              autoplayDuration: Duration(seconds: 5),
              animationCurve: Curves.fastOutSlowIn,
              animationDuration: Duration(milliseconds: 1000),
              dotSize: 8.0,
              dotSpacing: 10,
              dotColor: Colors.black,
              dotIncreasedColor: Color(0xFFFF335C),
              dotBgColor: Colors.orange[200].withOpacity(0.5),
              dotPosition: DotPosition.bottomCenter,
              dotVerticalPadding: 00.0,
              borderRadius: true,
              radius: Radius.circular(40),
              overlayShadow: true,
              overlayShadowColors: Colors.brown,
              overlayShadowSize: 0.2,
              showIndicator: true,
              indicatorBgPadding: 10.0,
              images: [
                AssetImage('images/markiting.jpg'),
                AssetImage('images/carasol1.jpg'),
                AssetImage('images/carasol2.jpg'),
                AssetImage('images/carasol3.jpg'),
                AssetImage('images/carasol4.jpg'),
                AssetImage('images/carasol5.jpg'),
                AssetImage('images/carasol6.jpg'),
              ],
            ),
          ),
          Container(
            color: Colors.orange[50],
            padding: EdgeInsets.all(5),
            child: Text(
              "Questions",
              style: TextStyle(
                fontSize: 30,
                color: Colors.pink[900],
              ),
            ),
          ),
          Container(
            color: Colors.orange[50],
            height: 500,
            padding: EdgeInsets.all(5),
            child: myLocation != null
                ? StreamBuilder(
              stream: getDocumentNearB(myLocation),
              builder: (context, AsyncSnapshot<List> snapshot) {
                if (snapshot.data == null)
                  return new Container(
                    child: Center(child: new CircularProgressIndicator()),
                  );
                else
                  return Container(
                    height: MediaQuery.of(context).size.height,
                    width: MediaQuery.of(context).size.width,
                    child: ListView.builder(
                      itemCount: snapshot.data.length,
                      itemBuilder: (context, index) {
                        return Card(
                          child: Container(
                            color: Colors.grey[200],
                            height: 150,
                            padding: const EdgeInsets.all(0),
                            child: Row(children: [
                              Expanded(
                                flex: 3,
                                child: Container(
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: NetworkImage(
                                              'https://png.pngtree.com/png-vector/20200216/ourlarge/pngtree-fast-food-mexican-restaurant-building-cartoon-png-image_2148727.jpg'),
                                          fit: BoxFit.contain)),
                                ),
                              ),
                              Spacer(
                                flex: 1,
                              ),
                              Expanded(
                                flex: 10,
                                child: Container(
                                  height: 150,
                                  //padding: const EdgeInsets.only(top: 5),
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                    MainAxisAlignment.end,
                                    children: [
                                      Expanded(
                                          child: Text(
                                              "Store Name: " +
                                                  snapshot.data[index]
                                                  ['storeName']
                                                      .toString(),
                                              style: TextStyle(
                                                  fontSize: 20.0,
                                                  fontWeight:
                                                  FontWeight.bold,
                                                  color:
                                                  Colors.pink[900]))),

                                      Row(
                                        children: [
                                          Expanded(
                                            child: Text(
                                              "Question :" +
                                                  snapshot.data[index][
                                                  'advertiserQuestion']
                                                      .toString() +
                                                  "\n",
                                              style: TextStyle(
                                                  fontSize: 20.0,
                                                  fontWeight:
                                                  FontWeight.bold),
                                            ),
                                          )
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          Expanded(
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                  left: 3, right: 3),
                                              child: FlatButton(
                                                textColor: Colors.white,
                                                color: Colors.green,
                                                child: Text(
                                                  'True',
                                                  style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 20.0,
                                                  ),
                                                ),
                                                onPressed: () {
                                                  if (snapshot.data[index]
                                                  [
                                                  '_questionAnswer'] ==
                                                      'True') {
                                                    String Qus_ID =
                                                    GetChallangeID(
                                                        snapshot
                                                            .data[
                                                        index]
                                                            .id
                                                            .toString());
                                                    createRecord(Qus_ID);
                                                  } else {
                                                    if (_firstPress) {
                                                      _firstPress =
                                                      false;
                                                      displayToastMassage(
                                                          'Thank you for answer',
                                                          context);
                                                    } else {
                                                      displayToastMassage(
                                                          'you have already answered!',
                                                          context);
                                                    }
                                                  }

                                                  //The user picked true.
                                                },
                                              ),
                                            ),
                                          ),
                                          Expanded(
                                            child: Padding(
                                              padding: EdgeInsets.only(
                                                  left: 3, right: 3),
                                              child: FlatButton(
                                                  color: Colors.red,
                                                  child: Text(
                                                    'False',
                                                    style: TextStyle(
                                                      fontSize: 20.0,
                                                      color: Colors.white,
                                                    ),
                                                  ),
                                                  onPressed: () {
                                                    if (snapshot.data[
                                                    index][
                                                    '_questionAnswer'] ==
                                                        'False') {
                                                      String Chall_ID =
                                                      GetChallangeID(
                                                          snapshot
                                                              .data[
                                                          index]
                                                              .id
                                                              .toString());
                                                      createRecord(
                                                          Chall_ID);
                                                    } else {
                                                      if (_firstPress) {
                                                        _firstPress =
                                                        false;
                                                        displayToastMassage(
                                                            'Thank you for answer',
                                                            context);
                                                      } else {
                                                        displayToastMassage(
                                                            'you have already answered!',
                                                            context);
                                                      }
                                                    }
                                                  }),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ]),
                          ),
                        );
                      },
                    ),
                  );
              },
            )
                : Center(
              child: Text(
                'your neighborhood is not covered by our Questions yet',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.grey,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            //CircularProgressIndicator(),
          )
        ]));
  }

  final winnersReference = FirebaseFirestore.instance.collection("winners");

  Future<String> getUserFirstName(String uid) async {
    final CollectionReference users = firestore.collection('Participants');
    DocumentReference documentReference =
    firestore.collection('Participants').doc(uid);
    String firstName;

    await documentReference.get().then((snapshot) {
      firstName = snapshot.data()['firstName'];
    });
    return firstName;
  }

  Future<String> getUserLastName(String uid) async {
    final CollectionReference users = firestore.collection('Participants');
    DocumentReference documentReference =
    firestore.collection('Participants').doc(uid);

    String lastName;

    await documentReference.get().then((snapshot) {
      lastName = snapshot.data()['lastName'];
    });
    return lastName;
  }

  Future<String> getStoreName(String uid) async {
    final CollectionReference users = firestore.collection('Advertisers');
    DocumentReference documentReference =
    firestore.collection('Advertisers').doc(uid);
    String storename;
    await documentReference.get().then((snapshot) {
      storename = snapshot.data()['storeName'];
    });
    return storename;
  }

  Future<bool> getQuestionAnswer(String uid) async {
    final CollectionReference users = firestore.collection('Questions');
    DocumentReference documentReference =
    firestore.collection('Questions').doc(uid);
    bool questionAnswer;
    await documentReference.get().then((snapshot) {
      questionAnswer = snapshot.data()['_questionAnswer'];
    });
    return questionAnswer;
  }

  Future<void> createRecord(String Qus_ID) async {
    print(Qus_ID);

    var userEmail = getUserEmail(auth.currentUser.uid).toString();

    var winner = await firestore
        .collection('winners')
        .where("QusID", isEqualTo: Qus_ID.toString())
        .where("email", isEqualTo: useremail)
        .get();
    print(useremail);
    print(winner.docs.length);
    print(winner.docs.isEmpty);

    if (winner.docs.isEmpty) {
      FirebaseFirestore.instance.collection("winners").add({
        "firstName ": await getUserFirstName(auth.currentUser.uid),
        "lastName": await getUserLastName(auth.currentUser.uid),
        "email": useremail,
        "userID": auth.currentUser.uid,
        "QusID": await Qus_ID,
      }).whenComplete(() {
        displayToastMassage('Your Answer Is True ', context);
      });
    } else {
      displayToastMassage('you have already answered! ', context);
    }
  }
}

displayToastMassage(String massag, BuildContext context) {
  Fluttertoast.showToast(
    msg: massag,
  );
}