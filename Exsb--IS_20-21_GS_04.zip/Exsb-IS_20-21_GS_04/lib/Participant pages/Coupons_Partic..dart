import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:geoflutterfire/geoflutterfire.dart';
import '../drawerPart.dart';
import 'NotifcationsPart.dart';


class CouponsPageForParticipants extends StatefulWidget {
  CouponsPageForParticipants({this.app});
  final FirebaseApp app;
  State<StatefulWidget> createState() {
    return CouponsPageForParticipantsState();
  }}
class CouponsPageForParticipantsState extends State<CouponsPageForParticipants> {
  final databaseReference = FirebaseDatabase.instance.reference();
  DatabaseReference Adsref;
  dynamic data;
  final firestore = FirebaseFirestore.instance;   //
  FirebaseAuth auth = FirebaseAuth.instance;     //recommend declaring a reference outside the methods

  Future<List> getAllCoupons() async {

    var users = await firestore.collection('Coupons').get();

    return users.docs;

  }


  Geoflutterfire geo = Geoflutterfire();
  GeoFirePoint myLocation;
  Future<GeoFirePoint> _getUserLocation() async {
    final CollectionReference par = firestore.collection("Participants");
    DocumentReference documentReference = par.doc(auth.currentUser.uid);
    GeoFirePoint point0;
    await documentReference.get().then((DocumentSnapshot snap) {
      if (snap.exists) {
        var fireBase = snap.data()['location'];
        point0 = geo.point(
            latitude: double.parse('${fireBase.latitude}'),
            longitude: double.parse('${fireBase.longitude}'));
      }
    });
    setState(() {
      myLocation = point0;
    });
  }
  Stream<List<DocumentSnapshot>> getDocumentNearB(GeoFirePoint userLocation) {
    double radius = 50;
    String field = 'position';
    var docRef = firestore.collection("Coupons");
    Stream<List<DocumentSnapshot>> query = geo
        .collection(collectionRef: docRef)
        .within(
        center: userLocation ,
        radius: radius,
        field: field,
        strictMode: true);

    return query;
  }
  @override
  void initState() {
    _getUserLocation();
    print('My location --> ${myLocation?.data}');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text("Advertising page" , style: TextStyle(color:Colors.pink[900]),),
          backgroundColor: Colors.orange[200],
          centerTitle: true,
          actions: [IconButton(icon: Icon(Icons.notifications, color: Colors.pink[900],), onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
              return notificationPart();
            }));
          })],

        ),

        drawer: OurDrawer(),
        body:

        ListView(
            scrollDirection: Axis.vertical,
            children: [
              Container(
                height: 180.0,
                width: double.infinity,
                child: Carousel(
                  boxFit: BoxFit.fill,
                  autoplay: true,
                  autoplayDuration: Duration(seconds: 5),
                  animationCurve: Curves.fastOutSlowIn,
                  animationDuration: Duration(milliseconds: 1000),
                  dotSize: 8.0,
                  dotSpacing: 10,
                  dotColor: Colors.black,
                  dotIncreasedColor: Color(0xFFFF335C),
                  dotBgColor: Colors.orange[200].withOpacity(0.5),
                  dotPosition: DotPosition
                      .bottomCenter,
                  dotVerticalPadding:00.0,
                  borderRadius: true,
                  radius: Radius.circular(40),
                  overlayShadow: true,
                  overlayShadowColors: Colors.brown,
                  overlayShadowSize:0.2,
                  showIndicator: true,
                  indicatorBgPadding: 10.0,
                  images: [
                    AssetImage('images/markiting.jpg'),
                    AssetImage('images/carasol1.jpg'),
                    AssetImage('images/carasol2.jpg'),
                    AssetImage('images/carasol3.jpg'),
                    AssetImage('images/carasol4.jpg'),
                    AssetImage('images/carasol5.jpg'),
                    AssetImage('images/carasol6.jpg'),
                  ],),),

              Container(
                color: Colors.orange[50],
                padding: EdgeInsets.all(5),
                child: Text("TOP 10, coming soon",
                  style: TextStyle(fontSize: 30, color: Colors.pink[900],
                  ),  ),),
              Container(
                color: Colors.orange[50],
                height: 90,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: [
                    Container(
                      height: 100,
                      width: 100,
                      child: ListTile(
                        subtitle: Container(
                          child: Text(
                            "Bist Discount" , style: TextStyle(color: Colors.pink[900] , fontSize: 15 ,),
                            textAlign: TextAlign.center,
                          ),),
                        title: Image.asset(
                          'images/arabburger.jpg',
                          width: 50,
                          height: 50,
                        ),
                      ),),
                    Container(
                      height: 100,
                      width: 100,
                      child: ListTile(
                        subtitle: Container(
                          child: Text(
                            "Bist Discount" , style: TextStyle(color: Colors.pink[900]),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        title: Image.asset(
                          'images/hardes.jpg',
                          width: 50,
                          height: 50,
                        ),  ), ),
                    Container(
                      height: 100,
                      width: 100,
                      child: ListTile(
                        subtitle: Container(
                          child: Text(
                            "Bist Discount" , style: TextStyle(color: Colors.pink[900]),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        title: Image.asset(
                          'images/shawaya.jpg',
                          width: 50,
                          height: 50,
                        ),
                      ),
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      child: ListTile(
                        subtitle: Container(
                          child: Text(
                            "Bist Discount" , style: TextStyle(color: Colors.pink[900]),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        title: Image.asset(
                          'images/herfy.jpg',
                          width: 50,
                          height: 50,
                        ),
                      ),
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      child: ListTile(
                        subtitle: Container(
                          child: Text(
                            "Bist Discount" , style: TextStyle(color: Colors.pink[900]),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        title: Image.asset(
                          'images/shawermr.jpg',
                          width: 50,
                          height: 50,
                        ),
                      ),
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      child: ListTile(
                        subtitle: Container(
                          child: Text(
                            "Bist Discount" , style: TextStyle(color: Colors.pink[900]),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        title: Image.asset(
                          'images/shormry.jpg',
                          width: 50,
                          height: 50,
                        ),
                      ),
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      child: ListTile(
                        subtitle: Container(
                          child: Text(
                            "Bist Discount" , style: TextStyle(color: Colors.pink[900]),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        title: Image.asset(
                          'images/subway.jpg',
                          width: 50,
                          height: 50,
                        ),
                      ),
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      child: ListTile(
                        subtitle: Container(
                          child: Text(
                            "Bist Discount" , style: TextStyle(color: Colors.pink[900]),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        title: Image.asset(
                          'images/tomaxburger.jpg',
                          width: 50,
                          height: 50,
                        ),
                      ),
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      child: ListTile(
                        subtitle: Container(
                          child: Text(
                            "Bist Discount" , style: TextStyle(color: Colors.pink[900]),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        title: Image.asset(
                          'images/kodo.jpg',
                          width: 50,
                          height: 50,
                        ),
                      ),
                    ),
                    Container(
                      height: 100,
                      width: 100,
                      child: ListTile(
                        subtitle: Container(
                          child: Text(
                            "Bist Discount" , style: TextStyle(color: Colors.pink[900]),
                            textAlign: TextAlign.center,),),
                        title: Image.asset(
                          'images/albeek.jpg',
                          width: 50,
                          height: 50,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                color: Colors.orange[50],
                padding: EdgeInsets.all(5),
                child: Text("Coupons", style: TextStyle(fontSize: 30, color: Colors.pink[900], ), ),),


              Container(
                color: Colors.orange[50],
                height: 500,
                padding: EdgeInsets.all(5),
                child:
                myLocation != null
                    ? StreamBuilder(
                  stream: getDocumentNearB(myLocation),
                  builder: (context, AsyncSnapshot<List> snapshot) {
                    if (snapshot.data == null)
                      return new Container(
                        child: Center(child: new CircularProgressIndicator()),
                      );
                    else
                      return Container(
                        height: MediaQuery.of(context).size.height,
                        width: MediaQuery.of(context).size.width,
                        child: ListView.builder(
                          itemCount: snapshot.data.length,
                          itemBuilder: (context, index) {
                            return Card(
                              child: Container(
                                color: Colors.grey[200],
                                height: 100,
                                padding: const EdgeInsets.all(0),
                                child: Row(children: [
                                  Expanded(
                                    flex: 6,
                                    child: Container(
                                      decoration: BoxDecoration(
                                          image: DecorationImage(
                                              image: NetworkImage(
                                                  'https://png.pngtree.com/png-vector/20200216/ourlarge/pngtree-fast-food-mexican-restaurant-building-cartoon-png-image_2148727.jpg'),
                                              fit: BoxFit.fill)),
                                    ),
                                  ),
                                  Spacer(
                                    flex: 1,
                                  ),
                                  Expanded(
                                    flex: 10,
                                    child: Container(
                                      //padding: const EdgeInsets.only(top: 5),
                                      child: Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        mainAxisAlignment:
                                        MainAxisAlignment.end,
                                        children: <Widget>[
                                          Text(
                                              "Store Name: " +
                                                  snapshot.data[index]
                                                  ['storeName']
                                                      .toString(),
                                              style: TextStyle(
                                                  fontSize: 20.0,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.deepOrange)),
                                          Row(
                                            children: <Widget>[
                                              Text(
                                                "Coupon code: " +
                                                    snapshot.data[index]
                                                    ['coupon_name']
                                                        .toString(),
                                                style: TextStyle(
                                                    fontSize: 20.0,
                                                    fontWeight:
                                                    FontWeight.bold),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            children: <Widget>[
                                              Text(
                                                "Discount value: " +
                                                    snapshot.data[index]
                                                    ['discount_value']
                                                        .toString() +
                                                    "%" +
                                                    "\n ",
                                                style: TextStyle(
                                                    fontWeight:
                                                    FontWeight.bold,
                                                    fontSize: 20,
                                                    color: Colors.pink[900]),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ]),
                              ),
                            );
                          },
                        ),
                      );
                  },
                )
                    : Center(
                  child: Text(
                    'your neighborhood is not covered by our coupons yet',
                    style: TextStyle(
                      fontSize: 20,
                      color: Colors.grey,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                //CircularProgressIndicator(),
              )
            ]));
  }

}
