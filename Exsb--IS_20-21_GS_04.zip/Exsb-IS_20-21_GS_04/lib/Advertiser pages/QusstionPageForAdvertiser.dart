import 'dart:async';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:exsb_app_gp/Participant%20pages/NotifcationsPart.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:geoflutterfire/geoflutterfire.dart';
import '../drawerADV.dart';
import 'AllCompitionsAdv.dart';


class QuistionAdv extends StatefulWidget {
  QuistionAdv({this.app});

  final FirebaseApp app;

  State<StatefulWidget> createState() {
    return _QuistionAdvState();
  }
}

class _QuistionAdvState extends State<QuistionAdv> {
  List<QuestionAnswer> rightAnswer = [
    QuestionAnswer('True'),
    QuestionAnswer('False')
  ];
  final firestore = FirebaseFirestore.instance; //
  FirebaseAuth auth = FirebaseAuth.instance;
  TextEditingController _advertiserQuestion = TextEditingController();
  TextEditingController _questionDeadline = TextEditingController();
  TextEditingController _StoreNameControllar = TextEditingController();
  TextEditingController _questionAnswer = TextEditingController();
  TimeOfDay _time = new TimeOfDay.now();
  DateTime pickedDate;

  _pickDate() async {
    DateTime date = await showDatePicker(
      context: context,
      firstDate: DateTime(DateTime.now().year),
      lastDate: DateTime(DateTime.now().year + 1),
      initialDate: pickedDate,
    );
    if (date != null)
      setState(() {
        pickedDate = date;
      });
  }

  Geoflutterfire geo = Geoflutterfire();

  Future<List> getAllQuestions() async {
    var Questions = await firestore.collection('Questions').get();
    // if (cupon.docs.toString()==auth.currentUser.uid) {
    return Questions.docs;
  }

  @override
  void initState() {
    super.initState();
    pickedDate = DateTime.now();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Questions page",
          style: TextStyle(color: Colors.pink[900]),
        ),
        backgroundColor: Colors.orange[200],
        centerTitle: true,
        actions: [
          IconButton(
              icon: Icon(
                Icons.notifications,
                color: Colors.pink[900],
              ),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (BuildContext context) {
                      return notificationPart();
                    }));
              })
        ],
      ),
      drawer: drawerADV(),
      body: Container(
        color: Colors.orange[50],
        child:ListView(
          scrollDirection: Axis.vertical,
          children: [
            Container(
              height: 180.0,
              width: double.infinity,
              child: Carousel(
                boxFit: BoxFit.fill,
                autoplay: true,
                autoplayDuration: Duration(seconds: 5),
                animationCurve: Curves.fastOutSlowIn,
                animationDuration: Duration(milliseconds: 1000),
                dotSize: 8.0,
                dotSpacing: 10,
                dotColor: Colors.black,
                dotIncreasedColor: Color(0xFFFF335C),
                dotBgColor: Colors.orange[200].withOpacity(0.5),
                dotPosition: DotPosition.bottomCenter,
                dotVerticalPadding: 00.0,
                borderRadius: true,
                radius: Radius.circular(40),
                overlayShadow: true,
                overlayShadowColors: Colors.brown,
                overlayShadowSize: 0.2,
                showIndicator: true,
                indicatorBgPadding: 10.0,
                images: [
                  AssetImage('images/markiting.jpg'),
                  AssetImage('images/carasol1.jpg'),
                  AssetImage('images/carasol2.jpg'),
                  AssetImage('images/carasol3.jpg'),
                  AssetImage('images/carasol4.jpg'),
                  AssetImage('images/carasol5.jpg'),
                  AssetImage('images/carasol6.jpg'),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.all(5),
              child: Text(
                "TOP 10, coming soon",
                style: TextStyle(
                  fontSize: 30,
                  color: Colors.pink[900],
                ),
              ),
            ),
            Container(
              height: 90,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(
                            color: Colors.pink[900],
                            fontSize: 15,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/arabburger.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/hardes.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/shawaya.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/herfy.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/shawermr.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/shormry.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/subway.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/tomaxburger.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/kodo.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/albeek.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: EdgeInsets.all(5),
              child: Text(
                "Questions",
                style: TextStyle(
                  fontSize: 30,
                  color: Colors.pink[900],
                ),
              ),
            ),
            Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              color: Colors.orange[50],
              child: ListView(
                children: [
                  Container(
                    child: TextFormField(
                      controller: _advertiserQuestion,
                      decoration: InputDecoration(
                          labelText: "Enter your question",
                          labelStyle: TextStyle(color: Colors.pink[900]),
                          fillColor: Colors.grey[200],
                          filled: true,
                          prefixIcon: Icon(
                            Icons.question_answer,
                            color: Colors.pink[900],
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                          )),
                    ),
                  ),
                  Container(
                    child: TextFormField(
                      controller: _questionAnswer,
                      decoration: InputDecoration(
                          labelText: "Write Question Answer Here [True or False]",
                          labelStyle: TextStyle(color: Colors.pink[900]),
                          fillColor: Colors.grey[200],
                          filled: true,
                          prefixIcon: Icon(
                            Icons.question_answer_outlined,
                            color: Colors.pink[900],
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                          )),
                    ),
                  ),
                  Text('\t ' + 'select date:',
                      style: TextStyle(
                          fontSize: 25,
                          color: Colors.pink[900]
                      )),
                  Container(
                    child: Card(
                      elevation: 0,
                      margin: EdgeInsets.symmetric(horizontal: 100, vertical: 5),
                      color: Colors.grey[200],
                      child: ListTile(
                        title: Text(
                            "Date: ${pickedDate.year}, ${pickedDate.month}, ${pickedDate.day}",
                            style: TextStyle(color: Colors.pink[900])),
                        trailing: Icon(Icons.calendar_today),
                        onTap: _pickDate,
                      ),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      RaisedButton(
                        padding: EdgeInsets.only(right: 80,left: 80),

                        color: Colors.pink[900],
                        shape: StadiumBorder(
                          side: BorderSide(
                            color: Colors.pink[900],
                          ),
                        ),
                        onPressed: () {
                          if (_advertiserQuestion.text.isEmpty) {
                            displayToastMassage('Please Enter Value', context);
                          } else {
                            createRecord().then((value) {
                              Timer(Duration(seconds: 3), () {
                                Navigator.pop(context);
                                Route route = MaterialPageRoute(builder: (c) => AllCompitionsAdv());
                                Navigator.pushReplacement(context, route);
                              });

                            });
                          }
                          //return AllCompitionsAdv();
                        },
                        child: Text(
                          'Save',
                          style: TextStyle(fontSize: 20, color: Colors.white
                            //decoration: new InputDecoration()
                          ),
                        ),
                      ),
                    ],
                  ),


                  StreamBuilder(
                      stream: QuestionsReference.where('userID',
                          isEqualTo: auth.currentUser.uid)
                          .snapshots(),
                      builder: (_, AsyncSnapshot<QuerySnapshot> snapshot) {
                        if (snapshot.hasData) {
                          return Container(
                              padding: EdgeInsets.all(10),
                              height: 500,
                              child: ListView.builder(
                                itemCount: snapshot.data.docs.length,
                                itemBuilder: (context, index) {
                                  var doc = snapshot.data.docs[index].data;

                                  ///  if (snapshot.data[index]['userID'].toString()==auth.currentUser.uid)
                                  return ListTile(
                                    tileColor: Colors.grey[200],
                                    title: Text(
                                        "Store Name: " +
                                            snapshot.data.docs[index]['storeName']
                                                .toString(),
                                        style: TextStyle(
                                            fontSize: 20.0,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.pink[900])),
                                    subtitle: Text(
                                        "Question: " +
                                            snapshot.data
                                                .docs[index]['advertiserQuestion']
                                                .toString(),
                                        style: TextStyle(
                                            fontSize: 20.0,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.deepOrangeAccent[200])),
                                    trailing: IconButton(
                                      icon: Icon(
                                        Icons.delete,
                                        color: Colors.pink[900],
                                      ),
                                      onPressed: () {
                                        snapshot.data.docs[index].reference
                                            .delete();
                                      },
                                    ),
                                  );
                                },
                              ));
                        } else
                          return new Container(
                            child: Center(child: new CircularProgressIndicator()),
                          );
                      })
                ],
              ),
            ),
          ],
        ) ,
      )

    );
  }

  Future<GeoPoint> getStoreLocation(String uid) async {
    final CollectionReference users = firestore.collection('Advertisers');
    DocumentReference documentReference = users.doc(uid);
    GeoPoint locations;
    await documentReference.get().then((snapshot) {
      locations = snapshot.data()['location'];
    });
    return locations;
  }

  Future<String> getStoreName(String uid) async {
    final CollectionReference users = firestore.collection('Advertisers');
    DocumentReference documentReference =
    firestore.collection('Advertisers').doc(uid);
    String storename;
    await documentReference.get().then((snapshot) {
      storename = snapshot.data()['storeName'];
    });
    return storename;
  }

  Future<void> createRecord() async {
    QuestionsReference.add({
      'advertiserQuestion': _advertiserQuestion.text,
      'questionDeadline':
      "${pickedDate.year}, ${pickedDate.month}, ${pickedDate.day}",
      "storeName": await getStoreName(auth.currentUser.uid),
      "store_location": await getStoreLocation(auth.currentUser.uid),
      "userID": auth.currentUser.uid,
      "position": await _someFunction(auth.currentUser.uid),
      "_questionAnswer": _questionAnswer.text,
    });
    _advertiserQuestion.clear();
    _questionDeadline.clear();
    _questionAnswer.clear();

    displayToastMassage('Qusetion has been added sucsseflly', context);
  }

  final QuestionsReference = FirebaseFirestore.instance.collection("Questions");

  Future<dynamic> _someFunction(String uid) async {
    final CollectionReference users = firestore.collection('Advertisers');
    DocumentReference documentReference = users.doc(uid);
    GeoFirePoint point;
    await documentReference.get().then((DocumentSnapshot snap) {
      var fireBase = snap.data()['location'];
      point = geo.point(
          latitude: double.parse('${fireBase.latitude}'),
          longitude: double.parse('${fireBase.longitude}'));
      print(point.data);
    });
    return point.data;
  }
}

class QuestionAnswer {
  QuestionAnswer(this.rightAnswer);

  String rightAnswer;
  bool isSelected = false;
}

displayToastMassage(String massag, BuildContext context) {
  Fluttertoast.showToast(
    msg: massag,
  );

  // is the flag of Saudi Arabia green and white?
  //is flag of Saudi Arabia red and green?
  //Are the numbers of weekdays 7 ?
}