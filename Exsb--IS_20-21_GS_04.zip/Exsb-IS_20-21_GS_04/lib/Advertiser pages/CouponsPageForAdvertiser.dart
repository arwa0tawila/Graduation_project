import 'package:carousel_pro/carousel_pro.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dio/dio.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geoflutterfire/geoflutterfire.dart';
import '../drawerADV.dart';
import 'NotificationsAdv.dart';
class CouponsPageForAdvertiser extends StatefulWidget {
  CouponsPageForAdvertiser({this.app});

  final FirebaseApp app;

  State<StatefulWidget> createState() {
    return CouponsPageForAdvertiserState();
  }
}

class CouponsPageForAdvertiserState extends State<CouponsPageForAdvertiser> {

  final firestore = FirebaseFirestore.instance; //
  FirebaseAuth auth = FirebaseAuth
      .instance; //recommend declaring a reference outside the methods
  TextEditingController _CoupnCodeControllar = TextEditingController();
  TextEditingController _StoreNameControllar = TextEditingController();
  final postUrl = "https://fcm.googleapis.com/fcm/send";
  Geoflutterfire geo = Geoflutterfire();

  Future<List> getAllCoupons() async {
    var cupon = await firestore.collection('Coupons').get();
    return cupon.docs;

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Advertising page  222",
          style: TextStyle(color: Colors.pink[900]),
        ),
        backgroundColor: Colors.orange[200],
        centerTitle: true,
        actions: [
          IconButton(
              icon: Icon(
                Icons.notifications,
                color: Colors.pink[900],
              ),
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (BuildContext context) {
                      return notificationAdv();
                    }));
              })
        ],
      ),
      drawer: drawerADV(),
      body: Container(
        color: Colors.orange[50],
        child:ListView(
          //  scrollDirection: Axis.vertical,
          children: [
            Container(
              height: 200.0,
              width: double.infinity,
              child: Carousel(
                boxFit: BoxFit.fill,
                autoplay: true,
                autoplayDuration: Duration(seconds: 5),
                animationCurve: Curves.fastOutSlowIn,
                animationDuration: Duration(milliseconds: 1000),
                dotSize: 8.0,
                dotSpacing: 10,
                dotColor: Colors.black,
                dotIncreasedColor: Color(0xFFFF335C),
                dotBgColor: Colors.orange[200].withOpacity(0.5),
                dotPosition: DotPosition.bottomCenter,
                dotVerticalPadding: 00.0,
                borderRadius: true,
                radius: Radius.circular(40),
                overlayShadow: true,
                overlayShadowColors: Colors.brown,
                overlayShadowSize: 0.2,
                showIndicator: true,
                indicatorBgPadding: 10.0,
                images: [
                  AssetImage('images/markiting.jpg'),
                  AssetImage('images/carasol1.jpg'),
                  AssetImage('images/carasol2.jpg'),
                  AssetImage('images/carasol3.jpg'),
                  AssetImage('images/carasol4.jpg'),
                  AssetImage('images/carasol5.jpg'),
                  AssetImage('images/carasol6.jpg'),
                ],
              ),
            ),

            Container(
              padding: EdgeInsets.all(5),
              child: Text(
                "TOP 10, coming soon!",
                style: TextStyle(
                  fontSize: 30,
                  color: Colors.pink[900],
                ),
              ),
            ),

            Container(
              height: 90,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(
                            color: Colors.pink[900],
                            fontSize: 15,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/arabburger.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/hardes.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/shawaya.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/herfy.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/shawermr.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/shormry.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/subway.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/tomaxburger.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/kodo.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: ListTile(
                      subtitle: Container(
                        child: Text(
                          "Bist Discount",
                          style: TextStyle(color: Colors.pink[900]),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      title: Image.asset(
                        'images/albeek.jpg',
                        width: 50,
                        height: 50,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            // -------------------------------Best-----------------------------------
            Container(
              padding: EdgeInsets.all(5),
              child: Text(
                "Coupons",
                style: TextStyle(
                  fontSize: 30,
                  color: Colors.pink[900],
                ),
              ),
            ),
            Container(
              height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.all(8),
              child: ListView(
                scrollDirection: Axis.vertical,
                children: [
                  Container(
                    height: MediaQuery.of(context).size.height,
                    width: MediaQuery.of(context).size.width,
                    //color: Colors.grey[200],

                    child: ListView(
                      children: [
                        Container(
                          child: TextFormField(
                            controller: _StoreNameControllar,
                            decoration: InputDecoration(
                                labelText: "Discount value",
                                labelStyle: TextStyle(color: Colors.pink[900]),
                                fillColor: Colors.grey[200],
                                filled: true,
                                prefixIcon: Icon(
                                  Icons.store, color: Colors.pink[900],
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20),
                                )),
                          ),
                        ),
                        Container(
                          child: TextFormField(
                            controller: _CoupnCodeControllar,
                            decoration: InputDecoration(
                                labelText: "Discount code",
                                labelStyle: TextStyle(color: Colors.pink[900]),
                                fillColor: Colors.grey[200],
                                filled: true,
                                prefixIcon: Icon(
                                  Icons.crop_free,color: Colors.pink[900],
                                ),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(20),
                                )),
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            RaisedButton(
                              padding: EdgeInsets.only(right: 80,left: 80),
                              color: Colors.pink[900],
                              shape: StadiumBorder(
                                side: BorderSide(
                                  color: Colors.pink[900],
                                ),
                              ),
                              //elevation: ,
                              onPressed: () {
                                if (_StoreNameControllar.text.isEmpty ||
                                    _CoupnCodeControllar.text.isEmpty) {
                                  displayToastMassage(
                                      'Please Enter Valid Code', context);
                                } else if (_CoupnCodeControllar.text.length < 5 ||
                                    _CoupnCodeControllar.text.length > 5) {
                                  displayToastMassage(
                                      '_CoupnCode must be = 5 character', context);
                                } else if (_StoreNameControllar.text.length < 2 ||
                                    _StoreNameControllar.text.length > 2) {
                                  displayToastMassage(
                                      '_CoupnCode must be = 2 number only',
                                      context);
                                } else {
                                  createRecord();
                                }
                              },
                              child: Text(
                                'Save',
                                style: TextStyle(fontSize: 20, color: Colors.white
                                ),
                              ),
                            ),
                          ],
                        ),


                        StreamBuilder(
                            stream: couponsReference.where('userID', isEqualTo:auth.currentUser.uid).snapshots(),
                            builder: (_, AsyncSnapshot<QuerySnapshot> snapshot) {
                              if (snapshot.hasData) {
                                return Container(
                                    padding: EdgeInsets.all(5),
                                    height: 500,
                                    child: ListView.builder(
                                      itemCount: snapshot.data.docs.length,
                                      itemBuilder: (context, index) {
                                        var doc = snapshot.data.docs[index].data;

                                        return ListTile(
                                          tileColor: Colors.grey[200],
                                          title: Text(
                                              "Store Name: " +
                                                  snapshot.data
                                                      .docs[index]['storeName']
                                                      .toString(),
                                              style: TextStyle(
                                                  fontSize: 20.0,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.pink[900])),
                                          subtitle: Text(
                                              "coupon code: " +
                                                  snapshot.data
                                                      .docs[index]['coupon_name']
                                                      .toString(),
                                              style: TextStyle(
                                                  fontSize: 20.0,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors
                                                      .deepOrangeAccent[200])),
                                          trailing: IconButton(
                                            icon: Icon(
                                              Icons.delete,
                                              color: Colors.pink[900],
                                            ),
                                            onPressed: () {
                                              snapshot.data.docs[index].reference
                                                  .delete();
                                            },
                                          ),
                                        );
                                        //);
                                      },
                                    ));
                              } else
                                return new Container(
                                  child: Center(
                                      child: new CircularProgressIndicator()),
                                );
                            })

                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ) ,
      )

    );
  }
  Future<GeoPoint> getStoreLocation(String uid) async {
    final CollectionReference users = firestore.collection('Advertisers');
    DocumentReference documentReference = users.doc(uid);
    GeoPoint locations;
    await documentReference.get().then((snapshot) {
      locations = snapshot.data()['location'];
    });
    return locations;

  }

  Future<String> getStoreName(String uid) async {
    final CollectionReference users = firestore.collection('Advertisers');
    DocumentReference documentReference =
    firestore.collection('Advertisers').doc(uid);
    String storename;
    await documentReference.get().then((snapshot) {
      storename = snapshot.data()['storeName'];
    });
    return storename;

  }

  Future<void> createRecord() async {
    // displayToastMassage('try1', context);
    var storeLocation = await getStoreLocation(auth.currentUser.uid);
    couponsReference.add({
      'discount_value': _StoreNameControllar.text,
      'coupon_name': _CoupnCodeControllar.text,
      "storeName": await getStoreName(auth.currentUser.uid),
      "store_location": storeLocation,
      "userID": auth.currentUser.uid,
      "position": await _someFunction(auth.currentUser.uid),
    }).then((value) {
      // Create a geoFirePoint
      GeoFirePoint center = geo.point(
          latitude: storeLocation.latitude, longitude: storeLocation.longitude);

// get the collection reference or query
      var collectionReference =
      FirebaseFirestore.instance.collection('Participants');

      double radius = 50;
      String field = 'position';

      Stream<List<DocumentSnapshot>> stream = geo
          .collection(collectionRef: collectionReference)
          .within(center: center, radius: radius, field: field);


      stream.listen((event) {
        event.forEach((element) {
          print('There are me ${element.data().toString()}');
          sendNotification(element.get('token'), 'Any thing');
        });
      });
    });

    _CoupnCodeControllar.clear();
    _StoreNameControllar.clear();

    displayToastMassage('Coupn Code has been added sucsseflly', context);

  }

  final couponsReference = FirebaseFirestore.instance.collection("Coupons");

  Future<void> Deletecoupon(String docID) async {
    // displayToastMassage('try1', context);
    String s = couponsReference.doc().id.toString();
    print(s);
    couponsReference.doc(docID).delete();

    displayToastMassage('Coupn Code has been deleted sucsseflly', context);

  }

  Future<dynamic> _someFunction(String uid) async {
    final CollectionReference users = firestore.collection('Advertisers');
    DocumentReference documentReference = users.doc(uid);
    GeoFirePoint point;
    await documentReference.get().then((DocumentSnapshot snap) {
      var fireBase = snap.data()['location'];
      point = geo.point(
          latitude: double.parse('${fireBase.latitude}'),
          longitude: double.parse('${fireBase.longitude}'));
      print(point.data);
    });
    return point.data;
  }

  Future<void> sendNotification(token, msg) async {
    final data = {
      "notification": {
        "body": "New Discount ",
        "title": "EXSB"
      },
      "priority": "high",
      "data": {
        "click_action": "FLUTTER_NOTIFICATION_CLICK",
        "id": "1",
        "status": "done"
      },
      "to": "$token"
    };
    final serverKey =
        'AAAAHws0U9c:APA91bHHOJxFOsCHjUo4fBFSsua_BjHy0ZCvgt2ojFjcL6USwWij7KMMljdfR9KSGuVxV1e0UJE-TLuQ2DBFn7xLDQUUbolnbR1h5tuFslkBJj4pHtXzEeTsa0KBbHudpuM1JgmGQuy-';
    final headers = {
      'content-type': 'application/json',
      'Authorization': 'key=$serverKey'
    };

    BaseOptions options = new BaseOptions(
      connectTimeout: 5000,
      receiveTimeout: 3000,
      headers: headers,
    );

    try {
      final response = await Dio(options).post(postUrl, data: data);

      if (response.statusCode == 200) {
      } else {
        print('notification sending failed');
      }
    } catch (e) {
      print('exception $e');
    }
  }
}

displayToastMassage(String massag, BuildContext context) {
  Fluttertoast.showToast(
    msg: massag,
  );
}