import 'package:flutter/material.dart';
import 'Advertiser pages/CreatAccountForAdvertiser.dart';
import 'Participant pages/creataccountforparticipant.dart';

class chooseusertocreataccount extends StatefulWidget {
  @override
  _chooseusertocreataccountState createState() => _chooseusertocreataccountState();
}

class _chooseusertocreataccountState extends State<chooseusertocreataccount> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('select user type ', style: TextStyle(color: Colors.pink[900])),
          centerTitle: true,
          backgroundColor: Colors.orange[200],

        ),
        body: Container(
          color: Colors.orange[50],
          child:ListView(
            padding: EdgeInsets.all(10),
            children: [
              SizedBox(height: 100,),

              Text('        SIGN UP AS', style: TextStyle(fontSize: 45, color: Colors.pink[900]),),
              SizedBox(height: 50,),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  RaisedButton(
                    padding: EdgeInsets.only(right: 80,left: 80),
                    color: Colors.pink[900],
                    //elevation: ,
                    shape:   StadiumBorder(
                      side: BorderSide(
                        color: Colors.pink[900],
                        width: 1.0,
                      ),
                    ),

                    //padding: ,
                    onPressed:(){
                      Navigator.push(
                          context, MaterialPageRoute(builder: (BuildContext context){
                        return CreatAccountForAdvertiser();
                      }));
                    },
                    child: Text('Advertiser', style: TextStyle(
                        fontSize: 30,
                        color: Colors.white
                    ),),
                  ),
                ],
              ),


              SizedBox(height: 30,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  RaisedButton(
                    padding: EdgeInsets.only(right: 80,left: 80),

                    color: Colors.pink[900],

                    shape:   StadiumBorder(
                      side: BorderSide(
                        color: Colors.pink[900],
                        width: 1.0,
                      ),
                    ),
                    //elevation: ,

                    onPressed:(){
                      Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
                        return CreatAccountForParticipant();
                      }));
                    },
                    child: Text('Participant', style: TextStyle(
                      fontSize: 30,
                      color: Colors.white,
                    ),),
                  ),
                ],
              )

            ],
          ) ,
        )

      ),
    );
  }
}
