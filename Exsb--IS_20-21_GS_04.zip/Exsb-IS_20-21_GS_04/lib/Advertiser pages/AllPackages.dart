import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import '../drawerADV.dart';
import 'DescriptionPackage.dart';
import 'NotificationsAdv.dart';

class package extends StatefulWidget {
  @override

  @override
  _packageState createState() => _packageState();
}

class _packageState extends State<package> {
  final firestore = FirebaseFirestore.instance;   //
  FirebaseAuth auth = FirebaseAuth.instance;     //recommend declaring a reference outside the methods


  Future<List> addpackage() async {
    var addpackage = await firestore.collection('addpackage').get();

    return addpackage.docs;
  }

  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('Packages',style: TextStyle(color: Colors.pink[900]),),
          centerTitle: true,
          backgroundColor: Colors.orange[200],

          actions: [IconButton(icon: Icon(Icons.notifications, color: Colors.pink[900],), onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
              return notificationAdv();
            }));
          })],
        ),
        drawer: drawerADV(),


        body: Container(
          color: Colors.orange[50],
          child:ListView(

            children: [

              Container(
                height: 130.0,
                width:double.infinity,// عشان يبقا الصورة بعرض الصفحة كلها
                child: Carousel(
                  // boxFit: BoxFit.cover, // عشان يخلي كل الصور اللي بضيفها اد الشاشة
                  autoplay: true , // ان الصور تتحرك بشكل تلقائي
                  autoplayDuration: Duration(seconds: 2), // كل اد ايه تتحرك الصورة
                  animationCurve: Curves.fastOutSlowIn,
                  animationDuration: Duration(milliseconds: 1000),
                  dotSize: 8.0, // خاصة بالدواير الصغيرة لما يحرك الصورة وكده والقيمة الافتراضية هيا 8
                  dotSpacing: 10, // المسافة ما بين كل نقطة والتانية
                  dotColor:Colors.black, // لون النقط
                  dotIncreasedColor: Color(0xFFFF335C), //dotBgColor: Colors.transparent,// بتكون كده لو مش عاوزة النقط وراها خلفية ولا حاجة
                  dotBgColor: Colors.pink[900].withOpacity(0.5),
                  dotPosition: DotPosition.bottomCenter,// هنا لها خلفية لونها اوارنج وفيها خاصية الشفافية
                  dotVerticalPadding: 00.0,// المسافة بين الشريط واسفل الصورة ، خليته 0 لان مش عاوزة مسافة
                  borderRadius: true , //بتخلي  الشريط اللى ورا النقط
                  radius: Radius.circular(40), // بتزود الدوران اللى ف الشريط
                  overlayShadow: true , // بتزود التظليل بتاع الشريط
                  overlayShadowColors: Colors.brown,// لون الشادو اللي ورا الخط
                  overlayShadowSize: 0.2, // مقاس الشادو الافتراضي 0.5 يعني المربع كله ولكن انا هنا حطيته كده لاني عاوزاه من تحت بس
                  showIndicator: true, // دي قيمتها الافتراضية ترو بحيث انه دايما يظهر النقط او الشريط لو اخترنا نحطه
                  indicatorBgPadding: 10.0, // عرض الشريط اللي ورا النقط

                  images: [ // الكارسول بيقبل صور من نوع ليست فيها كل الصور اللى جابة تنضاف للموقع
                    Image.asset('images/ad.jpg',fit: BoxFit.fill,),
                    Image.asset('images/ads.jpg',fit: BoxFit.fill,),
                    Image.asset('images/adv.jpg',fit: BoxFit.fill,),
                    Image.asset('images/adver.jpg',fit: BoxFit.fill,),
                    Image.asset('images/add.jpg',fit: BoxFit.fill,),
                    Image.asset('images/advs.jpg',fit: BoxFit.fill,),

                  ],
                ),
              ),
              SizedBox(height: 70,),
              Text('        Choose One Of The Package:\n', style: TextStyle(fontSize: 20, color: Colors.pink[900]),),

              FutureBuilder(
                future: addpackage(),
                builder: (context, AsyncSnapshot<List> snapshot) {
                  if (snapshot.data == null)
                    return new Container(
                      child: Center(child: new CircularProgressIndicator()),

                    );
                  else
                    return Container(
                      height: MediaQuery.of(context).size.height,
                      width: MediaQuery.of(context).size.width,

                      child: ListView.builder(
                        itemCount: snapshot.data.length,
                        itemBuilder: (context, index) {

                          return InkWell(
                            onTap: () {
                              Navigator.push(context, MaterialPageRoute(
                                  builder: (context) => DescriptionPackage(
                                    packegename: snapshot.data[index]['packegename'].toString(),
                                    description: snapshot.data[index]["description"].toString(),
                                  )));
                            },
                            child: Card(
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15.0),
                              ),
                              elevation: 20,

                              margin: EdgeInsets.symmetric(horizontal: 30, vertical: 7),
                              color: Colors.pink[900],



                              child: Container(

                                decoration:

                                BoxDecoration(color: Colors.pink[900]),
                                height: 100,
                                // padding: const EdgeInsets.all(0),
                                padding: const EdgeInsets.all(9.0),

                                child: Row(children: [

                                  Expanded(
                                    flex: 3,
                                    child: Container(

                                      decoration: new BoxDecoration(
                                          border: new Border(
                                              right: new BorderSide(
                                                  width: 1.0,
                                                  color: Colors.white24))),
                                      child: Icon(Icons.question_answer,
                                          color: Colors.white),
                                    ),
                                  ),
                                  Spacer(
                                    flex: 1,
                                  ),
                                  Expanded(
                                    flex: 10,
                                    child: Container(

                                      //padding: const EdgeInsets.only(top: 5),
                                      child: ListTile(
                                        title: Text(
                                            snapshot.data[index]['packegename']
                                                .toString(),
                                            style: TextStyle(
                                                fontSize: 20.0,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.white)),

                                      ),
                                    ),
                                  ),
                                ]),
                              ),
                            ),
                          );
                        },
                      ),
                    );
                },
              ),
            ],

          ) ,
        )

      ),
    );
  }
}