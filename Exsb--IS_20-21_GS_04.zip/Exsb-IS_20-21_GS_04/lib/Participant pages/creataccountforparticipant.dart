
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:exsb_app_gp/welcomeScreen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'VerifyScreen.dart';



class CreatAccountForParticipant extends StatefulWidget {
  @override
  _CreatAccountForParticipantState createState() => _CreatAccountForParticipantState();
}

class _CreatAccountForParticipantState extends State<CreatAccountForParticipant> {

  TextEditingController _firstNameField = TextEditingController();
  TextEditingController _lastNameField = TextEditingController();
  TextEditingController _emailAddressField = TextEditingController();
  TextEditingController _passwordField = TextEditingController();
  TextEditingController _phoneNumberField = TextEditingController();
  TextEditingController _birthDayField = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  String _email, _password;
  FirebaseAuth auth = FirebaseAuth.instance;


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('Creat Account For Participant', style: TextStyle(color: Colors.pink[900]),),
          centerTitle: true,
          backgroundColor: Colors.orange[200],

        ),
        body: Container(
          color: Colors.orange[50],
          key: _formKey,
          child: ListView(
            padding: EdgeInsets.all(10),
            children: [

              // Container()

              SizedBox(height: 50,width: 20,),
              TextFormField(

                controller: _firstNameField,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                    labelText: "first name ",
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.person, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),
              SizedBox(height: 10,width: 20,),
              TextFormField(

                controller: _lastNameField,
                keyboardType: TextInputType.name,
                decoration: InputDecoration(
                    labelText: "last name ",
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.person, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),
              SizedBox(height: 10,width: 20,),
              TextFormField(
                keyboardType: TextInputType.emailAddress,
                onChanged: (value) {
                  setState(() {
                    _email = value.trim();
                  });
                },
                controller: _emailAddressField,
                //keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                    hintText: "something@gmail.com",
                    labelText: "Email ",
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.mail, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),

              SizedBox(height: 10,width: 20,),
              TextFormField(
                onChanged: (value) {
                  setState(() {
                    _password = value.trim();
                  });
                },
                controller: _passwordField,
                obscuringCharacter: "*",
                obscureText: true,
                decoration: InputDecoration(
                    labelText: "Password ",
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.vpn_key, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),
              SizedBox(height: 10,width: 20,),
              TextFormField(
                controller: _phoneNumberField,
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                    labelText: "phone number ",
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.phone, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),

              SizedBox(height: 10,width: 20,),
              TextFormField(
                controller: _birthDayField,
                keyboardType: TextInputType.text,
                decoration: InputDecoration(
                    labelText: "Birthday ",
                    labelStyle: TextStyle(color: Colors.pink[900]),
                    fillColor: Colors.grey[200],
                    filled: true,
                    prefixIcon: Icon(Icons.calendar_today, color: Colors.pink[900],),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),

                    )
                ),
              ),

              SizedBox(height: 50,),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  RaisedButton(
                    // padding: EdgeInsets.only(right: 80,left: 80),
                    color: Colors.pink[900],
                    shape:   RoundedRectangleBorder(
                      side: BorderSide(
                        color: Colors.black54,
                        width: 1.0,
                      ),
                      borderRadius: BorderRadius.circular(50),
                    ),
                    //elevation: ,


                    onPressed: (){

                      //validation
                      _firstNameField.text.isNotEmpty;
                      _lastNameField.text.isNotEmpty;
                      _emailAddressField.text.isNotEmpty;
                      _passwordField.text.isNotEmpty;
                      _phoneNumberField.text.isNotEmpty;
                      _birthDayField.text.isNotEmpty;


                      if (_firstNameField.text.isEmpty || _lastNameField.text.isEmpty
                          || _emailAddressField.text.isEmpty || _passwordField.text.isEmpty
                          || _phoneNumberField.text.isEmpty){
                        displayToastMassage('All input is required', context);
                      }

                      if (! _emailAddressField.text.contains("@gmail.com")){
                        displayToastMassage('Email address should be @gmail.com', context);
                      }

                      else if ( _phoneNumberField.text.length != 10) {
                        displayToastMassage('Phone Number Must Be 10 Numbers', context);
                      }

                      else if ( _passwordField.text.length<6) {
                        displayToastMassage('password must be more than 7 character', context);
                      }
                      else{
                        registerUser();
                      }
                      return welcome();

                    },
                    child: Text('Create Account', style: TextStyle(
                        fontSize: 25,
                        color: Colors.white
                    ),),
                  ),
                ],
              )

            ],
          ),
        ),
      ),
    );
  }

  final FirebaseAuth _firebaseAuth = FirebaseAuth.instance;
  void registerUser() async{
    User firebaseUser;
    await _firebaseAuth.createUserWithEmailAndPassword
      (email: _emailAddressField.text.trim(),
      password: _passwordField.text.trim(),
    ).then((firebaseAuth) {
      firebaseUser = firebaseAuth.user;
    }).catchError((error){
      Navigator.pop(context);
    });

    if(firebaseUser != null){
      saveUserInfoToFireStore(firebaseUser).then((value){
        Navigator.pop(context);
        Route route = MaterialPageRoute(builder: (c) => VerifyScreen());
        Navigator.pushReplacement(context, route);
      });

    }
  }
  Future saveUserInfoToFireStore(User fUser) async {
    FirebaseFirestore.instance.collection("Participants").doc(fUser.uid).set({
      "firstName": _firstNameField.text.trim(),
      "lastName": _lastNameField.text.trim(),
      "email" : fUser.email,
      "Password" : _passwordField.text.trim(),
      "phoneNumber" : _phoneNumberField.text.trim(),
      "birthDay" : _birthDayField.text.trim(),
      "location": new GeoPoint(0,0),

    });
  }
}

displayToastMassage(String messag,  BuildContext context){
  Fluttertoast.showToast(msg: messag,);

}