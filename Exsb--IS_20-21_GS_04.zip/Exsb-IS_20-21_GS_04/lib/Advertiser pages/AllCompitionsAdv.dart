import 'package:exsb_app_gp/drawerPart.dart';
import 'package:exsb_app_gp/drawerADV.dart';
import 'package:flutter/material.dart';
import 'CouponsPageForAdvertiser.dart';
import 'NotificationsAdv.dart';
import 'PaymentDiamond.dart';
import 'PaymentGold.dart';
import 'TeamPageForAdvertiser.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class AllCompitionsAdv extends StatelessWidget {

  final firestore = FirebaseFirestore.instance;   //
  FirebaseAuth auth = FirebaseAuth.instance;     //recommend declaring a reference outside the methods


  @override
  Widget build(BuildContext context) {


    final title = "Home";
    return Scaffold(
        appBar: AppBar(
          elevation: 0.1,
          title: Text(
            title,
            style: TextStyle(
              color: Colors.pink[900],
              fontSize: 30.0,
              fontWeight: FontWeight.bold,
            ),
          ),
          backgroundColor: Colors.orange[200],
          centerTitle: true,
          actions: [IconButton(icon: Icon(Icons.notifications, color: Colors.pink[900],), onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (BuildContext context){
              return notificationAdv();
            }));
          })],


        ),
        drawer: drawerADV(),

        body: Container(
          color: Colors.orange[50],
          child: ListView(children: <Widget>[
            InkWell(
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => CouponsPageForAdvertiser())),
              child: Card(
                  color: Colors.white,
                  child: Column(
                    children: <Widget>[
                      new Container(
                          padding: const EdgeInsets.all(8.0),
                          child: Image.asset('images/f.jpg')),
                      new Container(
                        padding: const EdgeInsets.all(10.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'Coupons',
                              style: TextStyle(
                                color: Colors.pink[900],
                                fontSize: 30,
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                    crossAxisAlignment: CrossAxisAlignment.start,
                  )),
            ),
            InkWell(
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => PaymentGold())),
              child: Card(
                  color: Colors.white,
                  child: Column(
                    children: <Widget>[
                      new Container(
                          padding: const EdgeInsets.all(8.0),
                          child: Image.asset('images/Question2.jpg')),
                      new Container(
                        padding: const EdgeInsets.all(10.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'Questions',
                              style: TextStyle(
                                color: Colors.pink[900],
                                fontSize: 30,
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                    crossAxisAlignment: CrossAxisAlignment.start,
                  )),
            ),
            InkWell(
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => PaymentDiamond())),
              child: Card(
                  color: Colors.white,
                  child: Column(
                    children: <Widget>[
                      new Container(
                          padding: const EdgeInsets.all(8.0),
                          child: Image.asset('images/dd.jpg')),
                      new Container(
                        padding: const EdgeInsets.all(10.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'Challanges',
                              style: TextStyle(
                                color: Colors.pink[900],
                                fontSize: 30,
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                    crossAxisAlignment: CrossAxisAlignment.start,
                  )),
            ),
            InkWell(
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (context) => TeamChallangeAdv())),
              child: Card(
                  color: Colors.white,
                  child: Column(
                    children: <Widget>[
                      new Container(
                          padding: const EdgeInsets.all(8.0),
                          child: Image.asset('images/kk.jpg')),
                      new Container(
                        padding: const EdgeInsets.all(10.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'team Challange',
                              style: TextStyle(
                                color: Colors.pink[900],
                                fontSize: 30,
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                    crossAxisAlignment: CrossAxisAlignment.start,
                  )),
            ),
          ]),
        )

    );
  }
}

class menu {
  final String title;
  final String imglink;
  const menu({this.title, this.imglink});
}

