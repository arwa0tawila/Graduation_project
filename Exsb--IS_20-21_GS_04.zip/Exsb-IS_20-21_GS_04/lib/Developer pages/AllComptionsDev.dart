import 'dart:html';

import 'package:exsb_app_gp/Advertiser%20pages/CouponsPageForAdvertiser.dart';

import 'package:flutter/material.dart';



class AllCompitionsAdv extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    final title = "Home";
    return Scaffold(
        appBar: AppBar(
          elevation: 0.1,
          title: Text(
            title,
            style: TextStyle(
              color: Colors.pink[900],
              fontSize: 30.0,
            ),
          ),
          backgroundColor: Colors.orange[200],
          centerTitle: true,
        ),
        body: new ListView(children: <Widget>[
          InkWell(
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (context) => CouponsPageForAdvertiser())),
            child: Card(
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    new Container(
                        padding: const EdgeInsets.all(8.0),
                        child: Image.asset('images/f.jpg')),
                    new Container(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Coupons',
                            style: TextStyle(
                              color: Colors.pink[900],
                              fontSize: 30,
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                  crossAxisAlignment: CrossAxisAlignment.start,
                )),
          ),
          InkWell(
            child: Card(
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    new Container(

                        padding: const EdgeInsets.all(8.0),
                        child: Image.asset('images/Question2.jpg')),
                    new Container(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[

                          Text(
                            'Questions',
                            style: TextStyle(
                              color: Colors.pink[900],
                              fontSize: 30,
                            ),

                          ),

                        ],
                      ),
                    )
                  ],
                  crossAxisAlignment: CrossAxisAlignment.start,
                )),
          ),
          InkWell(
            child: Card(
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    new Container(
                        padding: const EdgeInsets.all(8.0),
                        child: Image.asset('images/dd.jpg')),
                    new Container(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Challanges',
                            style: TextStyle(
                              color: Colors.pink[900],
                              fontSize: 30,
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                  crossAxisAlignment: CrossAxisAlignment.start,
                )),
          ),
          InkWell(
            child: Card(
                color: Colors.white,
                child: Column(
                  children: <Widget>[
                    new Container(
                        padding: const EdgeInsets.all(8.0),
                        child: Image.asset('images/kk.jpg')),
                    new Container(
                      padding: const EdgeInsets.all(10.0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Team Challanges',
                            style: TextStyle(
                              color: Colors.pink[900],
                              fontSize: 30,
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                  crossAxisAlignment: CrossAxisAlignment.start,
                )),
          ),
        ]));
  }
}

class menu {

  final String title;
  final String imglink;
  const menu({this.title, this.imglink});
}
